package com.volumescroll.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** The accent colours used by the cards. White text is always readable on these. */
object Accent {
    val Violet = Color(0xFF6D4AFF)
    val Pink = Color(0xFFE6397A)
    val Orange = Color(0xFFF0701E)
    val Teal = Color(0xFF0F9D8A)
    val Blue = Color(0xFF2F6FE4)
    val Green = Color(0xFF2E9E5B)
    val Slate = Color(0xFF475569)
    val SlateLight = Color(0xFF64748B)
    val VioletDark = Color(0xFF4A2FD0)
    val PinkDark = Color(0xFFC21E5C)
    val OrangeDark = Color(0xFFD4520A)
    val TealDark = Color(0xFF0A7A6B)
    val BlueDark = Color(0xFF1D52BD)
    val GreenDark = Color(0xFF1E7D44)
}

object Tile {
    val Lavender = Color(0xFFE6E1FF)
    val Pink = Color(0xFFFFE0EC)
    val Peach = Color(0xFFFFE8D2)
    val Mint = Color(0xFFD9F5EA)
    val Sky = Color(0xFFDCEBFF)
    val Lemon = Color(0xFFFFF1BF)
    val Ink = Color(0xFF16161F)
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF16161F),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFECECF4),
    onPrimaryContainer = Color(0xFF16161F),
    background = Color(0xFFF4F4F9),
    onBackground = Color(0xFF16161F),
    surface = Color(0xFFF4F4F9),
    onSurface = Color(0xFF16161F),
    surfaceVariant = Color.White,
    onSurfaceVariant = Color(0xFF666676),
    outline = Color(0xFFE6E6EE),
    outlineVariant = Color(0xFFD6D6E2),
    error = Color(0xFFD92D20)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFF2F2F7),
    onPrimary = Color(0xFF16161F),
    primaryContainer = Color(0xFF2B2B36),
    onPrimaryContainer = Color(0xFFF2F2F7),
    background = Color(0xFF0B0B10),
    onBackground = Color(0xFFF2F2F7),
    surface = Color(0xFF0B0B10),
    onSurface = Color(0xFFF2F2F7),
    surfaceVariant = Color(0xFF17171E),
    onSurfaceVariant = Color(0xFFA8A8B8),
    outline = Color(0xFF26262F),
    outlineVariant = Color(0xFF3B3B4A),
    error = Color(0xFFFF6B5E)
)

@Composable
fun VolumeScrollTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, typography = Typography()) {
        Surface(color = colors.background, content = content)
    }
}
