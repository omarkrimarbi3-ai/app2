package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.volumescroll.app.ActionExecutor
import com.volumescroll.app.ActionRef
import com.volumescroll.app.ActionType
import com.volumescroll.app.Btn
import com.volumescroll.app.Category
import com.volumescroll.app.Gest
import com.volumescroll.app.R
import com.volumescroll.app.Scope
import com.volumescroll.app.SettingsState

@Composable
fun ActionPickerScreen(
    state: SettingsState,
    scope: Scope,
    btn: Btn,
    gest: Gest,
    onPicked: () -> Unit,
    onChooseApp: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val current = state.action(scope, btn, gest)
    val single = gest == Gest.SINGLE

    fun choose(type: ActionType) {
        state.changeAction(scope, btn, gest, ActionRef(type))
        onPicked()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(
            title = stringResource(btnName(btn)) + " · " + stringResource(gestName(gest)),
            subtitle = stringResource(R.string.picker_title),
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)
        ) {
            item {
                ActionRow(
                    label = ActionExecutor.label(context, ActionRef(ActionType.NONE), single),
                    desc = stringResource(if (single) R.string.a_none_single_desc else R.string.a_none_desc),
                    selected = current.type == ActionType.NONE
                ) { choose(ActionType.NONE) }
            }
            if (single) {
                item {
                    ActionRow(
                        label = stringResource(R.string.a_pass),
                        desc = stringResource(R.string.a_pass_desc),
                        selected = current.type == ActionType.PASS_THROUGH
                    ) { choose(ActionType.PASS_THROUGH) }
                }
            }

            Category.values().forEach { category ->
                val types = ActionType.values().filter {
                    it.category == category && ActionExecutor.isAvailable(context, it)
                }
                if (types.isNotEmpty()) {
                    item {
                        Text(
                            stringResource(category.label),
                            modifier = Modifier.padding(top = 20.dp, bottom = 4.dp),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    items(types) { type ->
                        if (type == ActionType.OPEN_APP) {
                            val label = ActionExecutor.label(
                                context,
                                if (current.type == ActionType.OPEN_APP) current else ActionRef(ActionType.OPEN_APP),
                                false
                            )
                            ActionRow(
                                label = label,
                                desc = null,
                                selected = current.type == ActionType.OPEN_APP
                            ) { onChooseApp() }
                        } else {
                            ActionRow(
                                label = stringResource(type.label),
                                desc = null,
                                selected = current.type == type
                            ) { choose(type) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppChooseScreen(onPick: (String) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(stringResource(R.string.choose_app), null, onBack)
        AppPickerList(
            trailing = { },
            onItemClick = { app -> onPick(app.pkg) }
        )
    }
}

@Composable
private fun ActionRow(label: String, desc: String?, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                label,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
            )
            if (desc != null) {
                Text(
                    desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (selected) {
            Icon(Icons.Filled.Check, contentDescription = null)
        }
    }
}
