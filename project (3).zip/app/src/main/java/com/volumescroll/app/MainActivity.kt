package com.volumescroll.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.volumescroll.app.ui.ActionPickerScreen
import com.volumescroll.app.ui.AppChooseScreen
import com.volumescroll.app.ui.AppsScreen
import com.volumescroll.app.ui.ButtonControlScreen
import com.volumescroll.app.ui.MainScreen
import com.volumescroll.app.ui.VolumeScrollTheme

private sealed interface Screen {
    data object Main : Screen
    data object Apps : Screen
    data object Buttons : Screen
    data class Picker(val scope: Scope, val btn: Btn, val gest: Gest) : Screen
    data class AppChoose(val scope: Scope, val btn: Btn, val gest: Gest) : Screen
}

class MainActivity : ComponentActivity() {

    private lateinit var state: SettingsState
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        state = SettingsState()

        setContent {
            VolumeScrollTheme {
                var screen by remember { mutableStateOf<Screen>(Screen.Main) }
                var buttonScope by remember { mutableStateOf(Scope.SELECTED) }
                val serviceOn = remember(resumeTick.intValue) { isAccessibilityEnabled(this) }

                when (val s = screen) {
                    Screen.Main -> MainScreen(
                        state = state,
                        serviceOn = serviceOn,
                        onOpenAccessibility = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                        onOpenAppInfo = {
                            startActivity(
                                Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", packageName, null)
                                )
                            )
                        },
                        onPickApps = { screen = Screen.Apps },
                        onOpenButtons = { screen = Screen.Buttons }
                    )

                    Screen.Apps -> AppsScreen(state = state, onBack = { screen = Screen.Main })

                    Screen.Buttons -> ButtonControlScreen(
                        state = state,
                        scope = buttonScope,
                        onScopeChange = { buttonScope = it },
                        onPick = { btn, gest -> screen = Screen.Picker(buttonScope, btn, gest) },
                        onBack = { screen = Screen.Main }
                    )

                    is Screen.Picker -> ActionPickerScreen(
                        state = state,
                        scope = s.scope,
                        btn = s.btn,
                        gest = s.gest,
                        onPicked = { screen = Screen.Buttons },
                        onChooseApp = { screen = Screen.AppChoose(s.scope, s.btn, s.gest) },
                        onBack = { screen = Screen.Buttons }
                    )

                    is Screen.AppChoose -> AppChooseScreen(
                        onPick = { pkg ->
                            state.changeAction(s.scope, s.btn, s.gest, ActionRef(ActionType.OPEN_APP, pkg))
                            screen = Screen.Buttons
                        },
                        onBack = { screen = Screen.Picker(s.scope, s.btn, s.gest) }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        state.refresh()
        resumeTick.intValue++
    }

    private fun isAccessibilityEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val mine = ComponentName(context, VolumeScrollService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == mine }
    }
}
