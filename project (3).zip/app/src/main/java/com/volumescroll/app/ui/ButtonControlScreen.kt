package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.volumescroll.app.ActionExecutor
import com.volumescroll.app.Btn
import com.volumescroll.app.Gest
import com.volumescroll.app.R
import com.volumescroll.app.Scope
import com.volumescroll.app.SettingsState

internal fun btnName(btn: Btn): Int =
    if (btn == Btn.UP) R.string.bc_vol_up else R.string.bc_vol_down

internal fun gestName(gest: Gest): Int = when (gest) {
    Gest.SINGLE -> R.string.bc_single
    Gest.LONG -> R.string.bc_long
    Gest.DOUBLE -> R.string.bc_double
}

@Composable
fun ButtonControlScreen(
    state: SettingsState,
    scope: Scope,
    onScopeChange: (Scope) -> Unit,
    onPick: (Btn, Gest) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(stringResource(R.string.bc_title), null, onBack)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScopeChip(
                    label = stringResource(R.string.bc_scope_apps),
                    selected = scope == Scope.SELECTED,
                    modifier = Modifier.weight(1f)
                ) { onScopeChange(Scope.SELECTED) }
                ScopeChip(
                    label = stringResource(R.string.bc_scope_other),
                    selected = scope == Scope.OTHER,
                    modifier = Modifier.weight(1f)
                ) { onScopeChange(Scope.OTHER) }
            }

            Text(
                stringResource(
                    if (scope == Scope.SELECTED) R.string.bc_scope_apps_desc else R.string.bc_scope_other_desc
                ),
                style = MaterialTheme.typography.bodyMedium,
                color = cs.onSurfaceVariant
            )

            if (scope == Scope.OTHER && Btn.values().any { !state.gestures(Scope.OTHER, it).isPassThrough }) {
                Text(
                    stringResource(R.string.bc_warn_other),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Btn.values().forEach { btn ->
                SectionCard {
                    SectionTitle(stringResource(btnName(btn)))
                    Gest.values().forEach { gest ->
                        val ref = state.action(scope, btn, gest)
                        GestureRow(
                            title = stringResource(gestName(gest)),
                            value = ActionExecutor.label(context, ref, gest == Gest.SINGLE)
                        ) { onPick(btn, gest) }
                    }
                }
            }

            Text(
                stringResource(R.string.bc_notes),
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )

            OutlinedButton(
                onClick = { state.resetButtons() },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(stringResource(R.string.bc_reset)) }
        }
    }
}

@Composable
private fun ScopeChip(
    label: String,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = if (selected) cs.primary else cs.surfaceVariant,
        contentColor = if (selected) cs.onPrimary else cs.onSurface,
        border = if (selected) null else BorderStroke(1.dp, cs.outline),
        modifier = modifier
    ) {
        Text(
            label,
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}

@Composable
private fun GestureRow(title: String, value: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            title,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold
        )
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = cs.background,
            border = BorderStroke(1.dp, cs.outlineVariant)
        ) {
            Text(
                value,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
