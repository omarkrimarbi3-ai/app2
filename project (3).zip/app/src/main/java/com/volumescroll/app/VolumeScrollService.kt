package com.volumescroll.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.ViewConfiguration
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Intercepts the physical volume keys (flagRequestFilterKeyEvents / onKeyEvent) and runs the action
 * the user assigned to the single press, long press or double press of each button.
 * Outside the configured cases the key is not consumed, so the system handles it normally.
 */
class VolumeScrollService : AccessibilityService() {

    private class KeyState {
        var longFired = false
        var longTask: Runnable? = null
        var pendingSingle: Runnable? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val keyStates = HashMap<Int, KeyState>()

    @Volatile private var currentPackage: String? = null
    private var ignoredPackages: Set<String> = setOf("com.android.systemui")

    private var lastScrollAt = 0L
    private var gestureInFlight = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        Prefs.init(this)
        refreshIgnoredPackages()
        Torch.init(this)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in ignoredPackages) return
        currentPackage = pkg
    }

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (!Prefs.enabled) return false
        if (isInCall()) return false

        val inSelectedApp = currentPackage?.let { it in Prefs.apps } == true
        val scope = if (inSelectedApp) Scope.SELECTED else Scope.OTHER
        val btn = if (code == KeyEvent.KEYCODE_VOLUME_UP) Btn.UP else Btn.DOWN
        val cfg = Prefs.gestures(scope, btn)

        // Untouched button: let the system handle it completely.
        if (cfg.isPassThrough) return false

        // Simple mode (no long / double press assigned): act immediately, hold repeats if repeatable.
        if (!cfg.hasLong && !cfg.hasDouble) {
            if (event.action == KeyEvent.ACTION_DOWN &&
                (event.repeatCount == 0 || cfg.single.type.repeatable)
            ) {
                ActionExecutor.execute(this, cfg.single, code)
            }
            return true
        }

        val state = keyStates.getOrPut(code) { KeyState() }
        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    state.longFired = false
                    state.longTask?.let { handler.removeCallbacks(it) }
                    state.longTask = null
                    if (cfg.hasLong) {
                        val task = Runnable {
                            state.longFired = true
                            state.pendingSingle?.let { handler.removeCallbacks(it) }
                            state.pendingSingle = null
                            ActionExecutor.execute(this, cfg.longPress, code)
                        }
                        state.longTask = task
                        handler.postDelayed(task, ViewConfiguration.getLongPressTimeout().toLong())
                    }
                }
            }
            KeyEvent.ACTION_UP -> {
                state.longTask?.let { handler.removeCallbacks(it) }
                state.longTask = null
                if (state.longFired) {
                    state.longFired = false
                } else if (cfg.hasDouble) {
                    val pending = state.pendingSingle
                    if (pending != null) {
                        handler.removeCallbacks(pending)
                        state.pendingSingle = null
                        ActionExecutor.execute(this, cfg.doublePress, code)
                    } else {
                        val task = Runnable {
                            state.pendingSingle = null
                            ActionExecutor.execute(this, cfg.single, code)
                        }
                        state.pendingSingle = task
                        handler.postDelayed(task, ViewConfiguration.getDoubleTapTimeout().toLong())
                    }
                } else {
                    ActionExecutor.execute(this, cfg.single, code)
                }
            }
        }
        return true
    }

    /** Swipe gesture. [towardsEnd] = scroll to the content below (finger moves up). */
    fun scroll(towardsEnd: Boolean) {
        val end = towardsEnd != Prefs.reverse
        val speed = Prefs.speed
        val distanceFraction = when (speed) {
            1 -> 0.25f; 2 -> 0.32f; 3 -> 0.40f; 4 -> 0.50f; else -> 0.60f
        }
        val durationMs = when (speed) {
            1 -> 450L; 2 -> 350L; 3 -> 260L; 4 -> 190L; else -> 130L
        }

        val now = SystemClock.uptimeMillis()
        if (gestureInFlight && now - lastScrollAt < 1000L) return
        if (now - lastScrollAt < durationMs + 40L) return

        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val centerY = dm.heightPixels / 2f
        val half = dm.heightPixels * distanceFraction / 2f

        val startY = if (end) centerY + half else centerY - half
        val endY = if (end) centerY - half else centerY + half

        val path = Path().apply {
            moveTo(x, startY)
            lineTo(x, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()

        gestureInFlight = true
        lastScrollAt = now
        val accepted = dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureInFlight = false
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureInFlight = false
            }
        }, null)
        if (!accepted) gestureInFlight = false
    }

    private fun isInCall(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
        return am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION
    }

    /** Keyboards and the system UI open windows too; they must not replace the foreground app. */
    private fun refreshIgnoredPackages() {
        val set = mutableSetOf("com.android.systemui")
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.enabledInputMethodList?.forEach { set.add(it.packageName) }
        ignoredPackages = set
    }
}
