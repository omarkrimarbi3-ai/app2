package com.volumescroll.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Single source of truth for settings. Initialised once from [VolumeScrollApp]. */
object Prefs {
    private const val FILE = "volume_scroll_prefs"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_SPEED = "speed"
    private const val KEY_REVERSE = "reverse"
    private const val KEY_APPS = "apps"
    private const val BTN_PREFIX = "btn."

    const val MIN_SPEED = 1
    const val MAX_SPEED = 5

    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        if (!::sp.isInitialized) {
            sp = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    var enabled: Boolean
        get() = sp.getBoolean(KEY_ENABLED, false)
        set(v) = sp.edit().putBoolean(KEY_ENABLED, v).apply()

    var speed: Int
        get() = sp.getInt(KEY_SPEED, 3).coerceIn(MIN_SPEED, MAX_SPEED)
        set(v) = sp.edit().putInt(KEY_SPEED, v.coerceIn(MIN_SPEED, MAX_SPEED)).apply()

    /** Reverses the direction of every scroll action. */
    var reverse: Boolean
        get() = sp.getBoolean(KEY_REVERSE, false)
        set(v) = sp.edit().putBoolean(KEY_REVERSE, v).apply()

    /** Package names of the "selected apps". Treat as read-only. */
    var apps: Set<String>
        get() = sp.getStringSet(KEY_APPS, emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet(KEY_APPS, HashSet(v)).apply()

    // ---- Button Control -------------------------------------------------------------------

    private fun btnKey(s: Scope, b: Btn, g: Gest) = "$BTN_PREFIX${s.name}.${b.name}.${g.name}"

    /** Defaults keep the original behaviour: scroll in selected apps, normal volume elsewhere. */
    fun defaultAction(s: Scope, b: Btn, g: Gest): ActionRef = when {
        g != Gest.SINGLE -> ActionRef(ActionType.NONE)
        s == Scope.OTHER -> ActionRef(ActionType.PASS_THROUGH)
        b == Btn.UP -> ActionRef(ActionType.SCROLL_UP)
        else -> ActionRef(ActionType.SCROLL_DOWN)
    }

    fun action(s: Scope, b: Btn, g: Gest): ActionRef =
        ActionRef.decode(sp.getString(btnKey(s, b, g), null)) ?: defaultAction(s, b, g)

    fun setAction(s: Scope, b: Btn, g: Gest, ref: ActionRef) {
        sp.edit().putString(btnKey(s, b, g), ref.encode()).apply()
    }

    fun gestures(s: Scope, b: Btn): Gestures = Gestures(
        action(s, b, Gest.SINGLE),
        action(s, b, Gest.LONG),
        action(s, b, Gest.DOUBLE)
    )

    fun resetButtons() {
        val editor = sp.edit()
        sp.all.keys.filter { it.startsWith(BTN_PREFIX) }.forEach { editor.remove(it) }
        editor.apply()
    }
}

/** Compose-observable mirror of [Prefs]; call [refresh] when the screen resumes. */
class SettingsState {
    var enabled by mutableStateOf(Prefs.enabled); private set
    var speed by mutableIntStateOf(Prefs.speed); private set
    var reverse by mutableStateOf(Prefs.reverse); private set
    var apps by mutableStateOf(Prefs.apps); private set
    private var buttonsRev by mutableIntStateOf(0)

    fun refresh() {
        enabled = Prefs.enabled
        speed = Prefs.speed
        reverse = Prefs.reverse
        apps = Prefs.apps
        buttonsRev++
    }

    fun changeEnabled(v: Boolean) { Prefs.enabled = v; enabled = v }
    fun changeSpeed(v: Int) { Prefs.speed = v; speed = Prefs.speed }
    fun changeReverse(v: Boolean) { Prefs.reverse = v; reverse = v }

    fun toggleApp(pkg: String) {
        val next = apps.toMutableSet()
        if (!next.add(pkg)) next.remove(pkg)
        Prefs.apps = next
        apps = next
    }

    fun action(s: Scope, b: Btn, g: Gest): ActionRef {
        buttonsRev // read so Compose re-runs callers when buttons change
        return Prefs.action(s, b, g)
    }

    fun gestures(s: Scope, b: Btn): Gestures {
        buttonsRev
        return Prefs.gestures(s, b)
    }

    fun changeAction(s: Scope, b: Btn, g: Gest, ref: ActionRef) {
        Prefs.setAction(s, b, g, ref)
        buttonsRev++
    }

    fun resetButtons() {
        Prefs.resetButtons()
        buttonsRev++
    }
}
