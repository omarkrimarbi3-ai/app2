package com.volumescroll.app

import androidx.annotation.StringRes

/** Where a button configuration applies. */
enum class Scope { SELECTED, OTHER }

enum class Btn { UP, DOWN }

enum class Gest { SINGLE, LONG, DOUBLE }

enum class Category(@StringRes val label: Int) {
    SCROLL(R.string.cat_scroll),
    VOLUME(R.string.cat_volume),
    TOOLS(R.string.cat_tools),
    NAVIGATION(R.string.cat_nav),
    SYSTEM(R.string.cat_system),
    APPS(R.string.cat_apps)
}

/**
 * Every action the app can really perform. [repeatable] actions keep firing while a button is held
 * (only when no long press or double press action is set for that button).
 */
enum class ActionType(
    @StringRes val label: Int,
    val category: Category?,
    val repeatable: Boolean = false
) {
    NONE(R.string.a_none, null),
    PASS_THROUGH(R.string.a_pass, null, true),

    SCROLL_UP(R.string.a_scroll_up, Category.SCROLL, true),
    SCROLL_DOWN(R.string.a_scroll_down, Category.SCROLL, true),

    VOLUME_UP(R.string.a_vol_up, Category.VOLUME, true),
    VOLUME_DOWN(R.string.a_vol_down, Category.VOLUME, true),
    VOLUME_PANEL(R.string.a_vol_panel, Category.VOLUME),

    FLASHLIGHT(R.string.a_torch, Category.TOOLS),
    CAMERA(R.string.a_camera, Category.TOOLS),
    CALCULATOR(R.string.a_calc, Category.TOOLS),

    HOME(R.string.a_home, Category.NAVIGATION),
    BACK(R.string.a_back, Category.NAVIGATION),
    RECENTS(R.string.a_recents, Category.NAVIGATION),

    NOTIFICATIONS(R.string.a_notif, Category.SYSTEM),
    QUICK_SETTINGS(R.string.a_qs, Category.SYSTEM),
    SETTINGS(R.string.a_settings, Category.SYSTEM),
    DISPLAY_SETTINGS(R.string.a_display, Category.SYSTEM),

    OPEN_APP(R.string.a_open_app, Category.APPS)
}

/** An action plus its optional argument (the package name for OPEN_APP). */
data class ActionRef(val type: ActionType, val arg: String? = null) {
    fun encode(): String = if (arg == null) type.name else "${type.name}:$arg"

    companion object {
        fun decode(s: String?): ActionRef? {
            if (s.isNullOrEmpty()) return null
            val idx = s.indexOf(':')
            val name = if (idx < 0) s else s.substring(0, idx)
            val arg = if (idx < 0) null else s.substring(idx + 1)
            val type = ActionType.values().firstOrNull { it.name == name } ?: return null
            return ActionRef(type, arg)
        }
    }
}

/** What one physical button does for single press, long press and double press. */
data class Gestures(
    val single: ActionRef,
    val longPress: ActionRef,
    val doublePress: ActionRef
) {
    val hasLong: Boolean
        get() = longPress.type != ActionType.NONE && longPress.type != ActionType.PASS_THROUGH
    val hasDouble: Boolean
        get() = doublePress.type != ActionType.NONE && doublePress.type != ActionType.PASS_THROUGH

    /** True when the button must behave exactly like the system default (we do not touch it). */
    val isPassThrough: Boolean
        get() = single.type == ActionType.PASS_THROUGH && !hasLong && !hasDouble
}
