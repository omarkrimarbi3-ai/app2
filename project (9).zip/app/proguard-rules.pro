# Standard safe rules for enums (values/valueOf are used when reading saved settings).
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
