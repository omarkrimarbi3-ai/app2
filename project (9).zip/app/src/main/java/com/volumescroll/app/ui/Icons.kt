package com.volumescroll.app.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Calculate
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RadioButtonChecked
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.ui.graphics.vector.ImageVector
import com.volumescroll.app.ActionType

/** One clean, consistent icon per action (instead of emoji). */
internal fun ActionType.icon(): ImageVector = when (this) {
    ActionType.NONE -> Icons.Rounded.Block
    ActionType.PASS_THROUGH -> Icons.Rounded.VolumeUp
    ActionType.SCROLL_UP -> Icons.Rounded.KeyboardArrowUp
    ActionType.SCROLL_DOWN -> Icons.Rounded.KeyboardArrowDown
    ActionType.VOLUME_UP -> Icons.Rounded.VolumeUp
    ActionType.VOLUME_DOWN -> Icons.Rounded.VolumeDown
    ActionType.VOLUME_PANEL -> Icons.Rounded.Tune
    ActionType.MEDIA_PLAY_PAUSE -> Icons.Rounded.PlayArrow
    ActionType.MEDIA_NEXT -> Icons.Rounded.SkipNext
    ActionType.MEDIA_PREVIOUS -> Icons.Rounded.SkipPrevious
    ActionType.FLASHLIGHT -> Icons.Rounded.FlashlightOn
    ActionType.CAMERA -> Icons.Rounded.CameraAlt
    ActionType.CALCULATOR -> Icons.Rounded.Calculate
    ActionType.HOME -> Icons.Rounded.Home
    ActionType.BACK -> Icons.AutoMirrored.Rounded.ArrowBack
    ActionType.RECENTS -> Icons.Rounded.Layers
    ActionType.NOTIFICATIONS -> Icons.Rounded.Notifications
    ActionType.QUICK_SETTINGS -> Icons.Rounded.Bolt
    ActionType.SETTINGS -> Icons.Rounded.Settings
    ActionType.DISPLAY_SETTINGS -> Icons.Rounded.BrightnessMedium
    ActionType.NEXT_PROFILE -> Icons.Rounded.SwapHoriz
    ActionType.OPEN_APP -> Icons.Rounded.Apps
    else -> Icons.Rounded.Bolt
}

internal object HubIcons {
    val Buttons: ImageVector get() = Icons.Rounded.Tune
    val Bubble: ImageVector get() = Icons.Rounded.RadioButtonChecked
    val Quick: ImageVector get() = Icons.Rounded.Bolt
    val Rules: ImageVector get() = Icons.Rounded.Smartphone
    val Profiles: ImageVector get() = Icons.Rounded.Person
    val Settings: ImageVector get() = Icons.Rounded.Settings
    val Active: ImageVector get() = Icons.Rounded.CheckCircle
    val Paused: ImageVector get() = Icons.Rounded.PauseCircle
    val Warn: ImageVector get() = Icons.Rounded.Warning
}
