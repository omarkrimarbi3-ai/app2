package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.volumescroll.app.ActionExecutor
import com.volumescroll.app.ActionRef
import com.volumescroll.app.ActionType
import com.volumescroll.app.Category
import com.volumescroll.app.R

/** Describes one "choose an action" request; [onResult] receives the choice. */
class PickReq(
    val title: String,
    val current: ActionRef,
    val allowPass: Boolean,
    val allowNone: Boolean,
    val noneLabel: Int,
    val noneDesc: Int,
    val onResult: (ActionRef) -> Unit
)

@Composable
fun ActionPickerScreen(
    req: PickReq,
    onChooseApp: () -> Unit,
    onDone: (ActionRef) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val current = req.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(
            title = req.title,
            subtitle = stringResource(R.string.picker_title),
            onBack = onBack
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)
        ) {
            if (req.allowNone) {
                item {
                    ActionRow(
                        icon = ActionType.NONE.icon(),
                        label = stringResource(req.noneLabel),
                        desc = stringResource(req.noneDesc),
                        selected = current.type == ActionType.NONE
                    ) { onDone(ActionRef(ActionType.NONE)) }
                }
            }
            if (req.allowPass) {
                item {
                    ActionRow(
                        icon = ActionType.PASS_THROUGH.icon(),
                        label = stringResource(R.string.a_pass),
                        desc = stringResource(R.string.a_pass_desc),
                        selected = current.type == ActionType.PASS_THROUGH
                    ) { onDone(ActionRef(ActionType.PASS_THROUGH)) }
                }
            }

            Category.values().forEach { category ->
                val types = ActionType.values().filter {
                    it.category == category && ActionExecutor.isAvailable(context, it)
                }
                if (types.isNotEmpty()) {
                    item {
                        Text(
                            stringResource(category.label),
                            modifier = Modifier.padding(top = 20.dp, bottom = 4.dp),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    items(types) { type ->
                        if (type == ActionType.OPEN_APP) {
                            val label = ActionExecutor.label(
                                context,
                                if (current.type == ActionType.OPEN_APP) current else ActionRef(ActionType.OPEN_APP),
                                false
                            )
                            ActionRow(
                                icon = type.icon(),
                                label = label,
                                desc = null,
                                selected = current.type == ActionType.OPEN_APP
                            ) { onChooseApp() }
                        } else {
                            ActionRow(
                                icon = type.icon(),
                                label = stringResource(type.label),
                                desc = null,
                                selected = current.type == type
                            ) { onDone(ActionRef(type)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppChooseScreen(onPick: (String) -> Unit, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(stringResource(R.string.choose_app), null, onBack)
        AppPickerList(
            trailing = { },
            onItemClick = { app -> onPick(app.pkg) }
        )
    }
}

@Composable
private fun ActionRow(icon: ImageVector, label: String, desc: String?, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBadge(icon, size = 40, modifier = Modifier.padding(end = 14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                label,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
            )
            if (desc != null) {
                Text(
                    desc,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (selected) {
            Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        }
    }
}
