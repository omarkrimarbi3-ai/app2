package com.volumescroll.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Single source of truth for settings, stored in SharedPreferences.
 * Button / rule / floating-shortcut settings belong to the ACTIVE profile. The built-in "default"
 * profile keeps the original key names, so settings from older versions are preserved.
 */
object Prefs {
    const val DEFAULT_PROFILE = "default"

    private const val FILE = "volume_scroll_prefs"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_SPEED = "speed"
    private const val KEY_REVERSE = "reverse"
    private const val KEY_LANG = "language"
    private const val KEY_DESIGN = "design"
    private const val KEY_ACTIVE = "active_profile"
    private const val KEY_PROFILES = "profiles"
    private const val KEY_SHORTCUTS = "shortcuts"

    const val MIN_SPEED = 1
    const val MAX_SPEED = 5

    private lateinit var sp: SharedPreferences

    val isReady: Boolean get() = ::sp.isInitialized

    fun init(context: Context) {
        if (!::sp.isInitialized) {
            sp = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    fun register(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        sp.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregister(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        sp.unregisterOnSharedPreferenceChangeListener(listener)
    }

    fun newId(): String = UUID.randomUUID().toString().substring(0, 8)

    // ---- Global settings ---------------------------------------------------------------------

    var enabled: Boolean
        get() = sp.getBoolean(KEY_ENABLED, false)
        set(v) = sp.edit().putBoolean(KEY_ENABLED, v).apply()

    var speed: Int
        get() = sp.getInt(KEY_SPEED, 3).coerceIn(MIN_SPEED, MAX_SPEED)
        set(v) = sp.edit().putInt(KEY_SPEED, v.coerceIn(MIN_SPEED, MAX_SPEED)).apply()

    /** Reverses the direction of every scroll action. */
    var reverse: Boolean
        get() = sp.getBoolean(KEY_REVERSE, false)
        set(v) = sp.edit().putBoolean(KEY_REVERSE, v).apply()

    /** Visual design: "white" (default), "ocean" or "bloom". The app is always light. */
    var design: String
        get() = sp.getString(KEY_DESIGN, "white") ?: "white"
        set(v) = sp.edit().putString(KEY_DESIGN, v).apply()

    var language: String
        get() = sp.getString(KEY_LANG, Lang.AR) ?: Lang.AR
        set(v) = sp.edit().putString(KEY_LANG, v).apply()

    // ---- Profiles ----------------------------------------------------------------------------

    var activeId: String
        get() = sp.getString(KEY_ACTIVE, DEFAULT_PROFILE) ?: DEFAULT_PROFILE
        set(v) = sp.edit().putString(KEY_ACTIVE, v).apply()

    /** Prefix of the keys that belong to the active profile ("" for the default one). */
    private fun pk(): String {
        val id = activeId
        return if (id == DEFAULT_PROFILE) "" else "p.$id."
    }

    fun profiles(): List<Profile> {
        val list = mutableListOf<Profile>()
        try {
            val arr = JSONArray(sp.getString(KEY_PROFILES, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Profile(o.getString("id"), o.optString("name", ""), o.optString("emoji", "⚪")))
            }
        } catch (e: Exception) {
            // Corrupted data: fall back to the default profile only.
        }
        if (list.none { it.id == DEFAULT_PROFILE }) list.add(0, Profile(DEFAULT_PROFILE, "", "⚪"))
        return list
    }

    private fun saveProfiles(list: List<Profile>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("emoji", it.emoji))
        }
        sp.edit().putString(KEY_PROFILES, arr.toString()).apply()
    }

    fun addProfile(name: String, emoji: String): Profile {
        val p = Profile(newId(), name, emoji)
        saveProfiles(profiles() + p)
        return p
    }

    fun editProfile(id: String, name: String, emoji: String) {
        saveProfiles(profiles().map { if (it.id == id) it.copy(name = name, emoji = emoji) else it })
    }

    fun deleteProfile(id: String) {
        if (id == DEFAULT_PROFILE) return
        if (activeId == id) activeId = DEFAULT_PROFILE
        saveProfiles(profiles().filter { it.id != id })
        removeKeys("p.$id.")
    }

    private fun removeKeys(prefix: String) {
        val editor = sp.edit()
        sp.all.keys.filter { it.startsWith(prefix) }.forEach { editor.remove(it) }
        editor.apply()
    }

    // ---- Selected apps group + app rules (active profile) -----------------------------------

    var apps: Set<String>
        get() = sp.getStringSet(pk() + "apps", emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet(pk() + "apps", HashSet(v)).apply()

    fun rules(): Set<String> = sp.getStringSet(pk() + "rules", emptySet()) ?: emptySet()

    fun addRule(pkg: String) {
        sp.edit().putStringSet(pk() + "rules", HashSet(rules() + pkg)).apply()
    }

    fun removeRule(pkg: String) {
        sp.edit().putStringSet(pk() + "rules", HashSet(rules() - pkg)).apply()
        removeKeys(pk() + "btn." + Source.App(pkg).key + ".")
    }

    // ---- Button Control (active profile) -----------------------------------------------------

    private fun btnKey(s: Source, b: Btn, g: Gest) = "${pk()}btn.${s.key}.${b.name}.${g.name}"

    /** Defaults keep the original behaviour: scroll in selected apps, normal volume elsewhere. */
    fun defaultAction(s: Source, b: Btn, g: Gest): ActionRef = when {
        g != Gest.SINGLE -> ActionRef(ActionType.NONE)
        s == Source.Others -> ActionRef(ActionType.PASS_THROUGH)
        b == Btn.UP -> ActionRef(ActionType.SCROLL_UP)
        else -> ActionRef(ActionType.SCROLL_DOWN)
    }

    fun action(s: Source, b: Btn, g: Gest): ActionRef =
        ActionRef.decode(sp.getString(btnKey(s, b, g), null)) ?: defaultAction(s, b, g)

    fun setAction(s: Source, b: Btn, g: Gest, ref: ActionRef) {
        sp.edit().putString(btnKey(s, b, g), ref.encode()).apply()
    }

    fun gestures(s: Source, b: Btn): Gestures = Gestures(
        action(s, b, Gest.SINGLE),
        action(s, b, Gest.LONG),
        action(s, b, Gest.DOUBLE)
    )

    fun resetButtons(s: Source) {
        removeKeys(pk() + "btn." + s.key + ".")
    }

    // ---- Shortcuts (shared) and floating shortcut (per profile) ------------------------------

    /** Shown until the user changes the list for the first time. */
    private fun defaultShortcuts(): List<Shortcut> = listOf(
        Shortcut("d_torch", "", null, ActionRef(ActionType.FLASHLIGHT)),
        Shortcut("d_camera", "", null, ActionRef(ActionType.CAMERA)),
        Shortcut("d_notif", "", null, ActionRef(ActionType.NOTIFICATIONS)),
        Shortcut("d_qs", "", null, ActionRef(ActionType.QUICK_SETTINGS)),
        Shortcut("d_settings", "", null, ActionRef(ActionType.SETTINGS))
    )

    fun shortcuts(): List<Shortcut> {
        if (!sp.contains(KEY_SHORTCUTS)) return defaultShortcuts()
        val list = mutableListOf<Shortcut>()
        try {
            val arr = JSONArray(sp.getString(KEY_SHORTCUTS, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val action = ActionRef.decode(o.optString("action", "")) ?: continue
                val emoji = if (o.has("emoji")) o.optString("emoji") else null
                list.add(Shortcut(o.getString("id"), o.optString("name", ""), emoji, action))
            }
        } catch (e: Exception) {
            // Corrupted data: ignore.
        }
        return list
    }

    fun saveShortcuts(list: List<Shortcut>) {
        val arr = JSONArray()
        list.forEach {
            val o = JSONObject().put("id", it.id).put("name", it.name).put("action", it.action.encode())
            if (it.emoji != null) o.put("emoji", it.emoji)
            arr.put(o)
        }
        sp.edit().putString(KEY_SHORTCUTS, arr.toString()).apply()
    }

    /** Until the user chooses, every shortcut is part of the floating menu. */
    fun bubbleIds(): Set<String> =
        sp.getStringSet(pk() + "bubble.ids", null) ?: shortcuts().map { it.id }.toSet()

    fun setBubbleIds(ids: Set<String>) {
        sp.edit().putStringSet(pk() + "bubble.ids", HashSet(ids)).apply()
    }

    /** Shortcuts shown in the floating menu of the active profile, in list order. */
    fun bubbleShortcuts(): List<Shortcut> {
        val ids = bubbleIds()
        return shortcuts().filter { it.id in ids }
    }

    private inline fun <reified T : Enum<T>> enumOr(name: String?, default: T): T =
        enumValues<T>().firstOrNull { it.name == name } ?: default

    fun bubble(): BubbleCfg {
        val p = pk() + "bubble."
        val d = BubbleCfg()
        return BubbleCfg(
            enabled = sp.getBoolean(p + "enabled", d.enabled),
            shape = enumOr(sp.getString(p + "shape", null), d.shape),
            emoji = sp.getString(p + "emoji", d.emoji) ?: d.emoji,
            sizeDp = sp.getInt(p + "size", d.sizeDp).coerceIn(BubbleStyle.MIN_SIZE, BubbleStyle.MAX_SIZE),
            alphaPct = sp.getInt(p + "alpha", d.alphaPct).coerceIn(BubbleStyle.MIN_ALPHA, 100),
            colorIdx = sp.getInt(p + "color", d.colorIdx).coerceIn(0, BubbleStyle.COLORS.size - 1),
            right = sp.getBoolean(p + "right", d.right),
            yPct = sp.getInt(p + "y", d.yPct).coerceIn(0, 100),
            trigger = enumOr(sp.getString(p + "trigger", null), d.trigger)
        )
    }

    fun saveBubble(c: BubbleCfg) {
        val p = pk() + "bubble."
        sp.edit()
            .putBoolean(p + "enabled", c.enabled)
            .putString(p + "shape", c.shape.name)
            .putString(p + "emoji", c.emoji)
            .putInt(p + "size", c.sizeDp)
            .putInt(p + "alpha", c.alphaPct)
            .putInt(p + "color", c.colorIdx)
            .putBoolean(p + "right", c.right)
            .putInt(p + "y", c.yPct)
            .putString(p + "trigger", c.trigger.name)
            .apply()
    }
}

/** Compose-observable mirror of [Prefs]; every change goes through here and refreshes the mirror. */
class SettingsState {
    var enabled by mutableStateOf(Prefs.enabled); private set
    var speed by mutableIntStateOf(Prefs.speed); private set
    var reverse by mutableStateOf(Prefs.reverse); private set
    var language by mutableStateOf(Prefs.language); private set
    var design by mutableStateOf(Prefs.design); private set
    var apps by mutableStateOf(Prefs.apps); private set
    var rules by mutableStateOf(Prefs.rules()); private set
    var activeId by mutableStateOf(Prefs.activeId); private set
    var profiles by mutableStateOf(Prefs.profiles()); private set
    var shortcuts by mutableStateOf(Prefs.shortcuts()); private set
    var bubbleIds by mutableStateOf(Prefs.bubbleIds()); private set
    var bubble by mutableStateOf(Prefs.bubble()); private set
    private var rev by mutableIntStateOf(0)

    fun refresh() {
        enabled = Prefs.enabled
        speed = Prefs.speed
        reverse = Prefs.reverse
        language = Prefs.language
        design = Prefs.design
        apps = Prefs.apps
        rules = Prefs.rules()
        activeId = Prefs.activeId
        profiles = Prefs.profiles()
        shortcuts = Prefs.shortcuts()
        bubbleIds = Prefs.bubbleIds()
        bubble = Prefs.bubble()
        rev++
    }

    // Global
    fun changeEnabled(v: Boolean) { Prefs.enabled = v; refresh() }
    fun changeSpeed(v: Int) { Prefs.speed = v; refresh() }
    fun changeReverse(v: Boolean) { Prefs.reverse = v; refresh() }
    fun changeLanguage(code: String) { Prefs.language = code; refresh() }
    fun changeDesign(name: String) { Prefs.design = name; refresh() }

    // Selected apps group
    fun toggleApp(pkg: String) {
        val next = Prefs.apps.toMutableSet()
        if (!next.add(pkg)) next.remove(pkg)
        Prefs.apps = next
        refresh()
    }

    // Buttons
    fun action(s: Source, b: Btn, g: Gest): ActionRef {
        rev // read so Compose re-runs callers when anything changes
        return Prefs.action(s, b, g)
    }

    fun gestures(s: Source, b: Btn): Gestures {
        rev
        return Prefs.gestures(s, b)
    }

    fun changeAction(s: Source, b: Btn, g: Gest, ref: ActionRef) {
        Prefs.setAction(s, b, g, ref)
        refresh()
    }

    fun resetButtons(s: Source) { Prefs.resetButtons(s); refresh() }

    // App rules
    fun addRule(pkg: String) { Prefs.addRule(pkg); refresh() }
    fun removeRule(pkg: String) { Prefs.removeRule(pkg); refresh() }

    // Profiles
    val activeProfile: Profile
        get() = profiles.firstOrNull { it.id == activeId } ?: profiles.first()

    fun switchProfile(id: String) { Prefs.activeId = id; refresh() }
    fun addProfile(name: String, emoji: String) {
        val p = Prefs.addProfile(name, emoji)
        Prefs.activeId = p.id
        refresh()
    }
    fun editProfile(id: String, name: String, emoji: String) { Prefs.editProfile(id, name, emoji); refresh() }
    fun removeProfile(id: String) { Prefs.deleteProfile(id); refresh() }

    // Shortcuts
    fun addShortcut(action: ActionRef, name: String = "", emoji: String? = null, inBubble: Boolean = true): Shortcut {
        val sc = Shortcut(Prefs.newId(), name, emoji, action)
        Prefs.saveShortcuts(Prefs.shortcuts() + sc)
        if (inBubble) Prefs.setBubbleIds(Prefs.bubbleIds() + sc.id)
        refresh()
        return sc
    }

    fun updateShortcut(id: String, change: (Shortcut) -> Shortcut) {
        Prefs.saveShortcuts(Prefs.shortcuts().map { if (it.id == id) change(it) else it })
        refresh()
    }

    fun removeShortcut(id: String) {
        Prefs.saveShortcuts(Prefs.shortcuts().filter { it.id != id })
        Prefs.setBubbleIds(Prefs.bubbleIds() - id)
        refresh()
    }

    fun moveShortcut(id: String, delta: Int) {
        val list = Prefs.shortcuts().toMutableList()
        val from = list.indexOfFirst { it.id == id }
        val to = from + delta
        if (from < 0 || to < 0 || to >= list.size) return
        val item = list.removeAt(from)
        list.add(to, item)
        Prefs.saveShortcuts(list)
        refresh()
    }

    fun toggleInBubble(id: String) {
        val ids = Prefs.bubbleIds()
        Prefs.setBubbleIds(if (id in ids) ids - id else ids + id)
        refresh()
    }

    // Floating shortcut
    fun updateBubble(change: (BubbleCfg) -> BubbleCfg) {
        Prefs.saveBubble(change(Prefs.bubble()))
        refresh()
    }
}
