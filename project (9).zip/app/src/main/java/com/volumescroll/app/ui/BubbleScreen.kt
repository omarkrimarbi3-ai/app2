package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.volumescroll.app.BubbleCfg
import com.volumescroll.app.BubbleShape
import com.volumescroll.app.BubbleStyle
import com.volumescroll.app.BubbleTrigger
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState
import kotlin.math.roundToInt

@Composable
fun BubbleScreen(
    state: SettingsState,
    serviceOn: Boolean,
    onOpenQuick: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val cfg = state.bubble
    val cs = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(
            stringResource(R.string.bubble_title),
            state.activeProfile.emoji,
            onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live preview on a mock screen (always left-to-right so left/right match the phone).
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp)
                        .clip(RoundedCornerShape(28.dp))
                        .background(Brush.linearGradient(listOf(Accent.Violet, Accent.Blue)))
                        .padding(12.dp),
                    contentAlignment = BiasAlignment(
                        horizontalBias = if (cfg.right) 1f else -1f,
                        verticalBias = cfg.yPct / 50f - 1f
                    )
                ) {
                    BubblePreview(cfg)
                }
            }
            HintText(stringResource(R.string.bubble_preview_hint))

            SectionCard {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        SectionTitle(stringResource(R.string.bubble_enable))
                        HintText(stringResource(R.string.bubble_enable_desc))
                    }
                    Switch(
                        checked = cfg.enabled,
                        onCheckedChange = { on -> state.updateBubble { it.copy(enabled = on) } }
                    )
                }
                if (!serviceOn) {
                    Text(
                        stringResource(R.string.bubble_need_service),
                        color = cs.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(
                        onClick = onOpenAccessibility,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) { Text(stringResource(R.string.perm_open)) }
                } else if (!state.enabled) {
                    Text(
                        stringResource(R.string.bubble_need_master),
                        color = cs.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            SectionCard {
                SectionTitle(stringResource(R.string.bubble_shape))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ShapeTile(cfg, BubbleShape.CIRCLE, R.string.shape_circle, Modifier.weight(1f)) {
                        state.updateBubble { c -> c.copy(shape = BubbleShape.CIRCLE) }
                    }
                    ShapeTile(cfg, BubbleShape.ROUNDED, R.string.shape_rounded, Modifier.weight(1f)) {
                        state.updateBubble { c -> c.copy(shape = BubbleShape.ROUNDED) }
                    }
                    ShapeTile(cfg, BubbleShape.CAPSULE, R.string.shape_capsule, Modifier.weight(1f)) {
                        state.updateBubble { c -> c.copy(shape = BubbleShape.CAPSULE) }
                    }
                }
            }

            SectionCard {
                SectionTitle(stringResource(R.string.bubble_icon))
                EmojiGrid(BubbleStyle.EMOJIS, cfg.emoji) { e -> state.updateBubble { it.copy(emoji = e) } }
            }

            SectionCard {
                SectionTitle(stringResource(R.string.bubble_color))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    BubbleStyle.COLORS.forEachIndexed { index, argb ->
                        val selected = index == cfg.colorIdx
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color(argb))
                                .border(
                                    if (selected) 3.dp else 1.dp,
                                    if (selected) cs.onSurface else cs.outline,
                                    CircleShape
                                )
                                .clickable { state.updateBubble { it.copy(colorIdx = index) } }
                        )
                    }
                }
            }

            SectionCard {
                SliderRow(
                    label = stringResource(R.string.bubble_size),
                    valueText = "${cfg.sizeDp} dp",
                    value = cfg.sizeDp.toFloat(),
                    range = BubbleStyle.MIN_SIZE.toFloat()..BubbleStyle.MAX_SIZE.toFloat()
                ) { v -> state.updateBubble { it.copy(sizeDp = v.roundToInt()) } }
                SliderRow(
                    label = stringResource(R.string.bubble_opacity),
                    valueText = "${cfg.alphaPct}%",
                    value = cfg.alphaPct.toFloat(),
                    range = BubbleStyle.MIN_ALPHA.toFloat()..100f
                ) { v -> state.updateBubble { it.copy(alphaPct = v.roundToInt()) } }
            }

            SectionCard {
                SectionTitle(stringResource(R.string.bubble_position))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillChip(
                        label = stringResource(R.string.bubble_left),
                        selected = !cfg.right,
                        modifier = Modifier.weight(1f)
                    ) { state.updateBubble { it.copy(right = false) } }
                    PillChip(
                        label = stringResource(R.string.bubble_right),
                        selected = cfg.right,
                        modifier = Modifier.weight(1f)
                    ) { state.updateBubble { it.copy(right = true) } }
                }
                SliderRow(
                    label = stringResource(R.string.bubble_height),
                    valueText = "${cfg.yPct}%",
                    value = cfg.yPct.toFloat(),
                    range = 0f..100f
                ) { v -> state.updateBubble { it.copy(yPct = v.roundToInt()) } }
                HintText(stringResource(R.string.bubble_drag_hint))
            }

            SectionCard {
                SectionTitle(stringResource(R.string.bubble_trigger))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillChip(
                        label = stringResource(R.string.trigger_tap),
                        selected = cfg.trigger == BubbleTrigger.TAP,
                        modifier = Modifier.weight(1f)
                    ) { state.updateBubble { it.copy(trigger = BubbleTrigger.TAP) } }
                    PillChip(
                        label = stringResource(R.string.trigger_long),
                        selected = cfg.trigger == BubbleTrigger.LONG,
                        modifier = Modifier.weight(1f)
                    ) { state.updateBubble { it.copy(trigger = BubbleTrigger.LONG) } }
                    PillChip(
                        label = stringResource(R.string.trigger_double),
                        selected = cfg.trigger == BubbleTrigger.DOUBLE,
                        modifier = Modifier.weight(1f)
                    ) { state.updateBubble { it.copy(trigger = BubbleTrigger.DOUBLE) } }
                }
            }

            SectionCard {
                SectionTitle(stringResource(R.string.bubble_menu_title))
                HintText(
                    stringResource(R.string.bubble_menu_count, state.shortcuts.count { it.id in state.bubbleIds })
                )
                OutlinedButton(
                    onClick = onOpenQuick,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(stringResource(R.string.bubble_manage), fontWeight = FontWeight.SemiBold) }
            }
        }
    }
}

@Composable
private fun SliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(valueText, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        AvoraSlider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun ShapeTile(
    cfg: BubbleCfg,
    shape: BubbleShape,
    labelRes: Int,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val selected = cfg.shape == shape
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = if (selected) cs.primaryContainer else cs.background,
        border = androidx.compose.foundation.BorderStroke(
            if (selected) 2.dp else 1.dp,
            if (selected) cs.primary else cs.outline
        ),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(Modifier.height(44.dp), contentAlignment = Alignment.Center) {
                BubblePreview(cfg.copy(shape = shape, sizeDp = 36, alphaPct = 100))
            }
            Text(
                stringResource(labelRes),
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}
