plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.volumescroll.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.volumescroll.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 8
        versionName = "1.6.0"
    }

    // Release signing: the key is NOT in the repository. CI passes it through environment
    // variables built from GitHub Secrets. Without them the release APK stays unsigned.
    val releaseKeystore = System.getenv("AVORA_KEYSTORE_PATH")
    val releasePassword = System.getenv("AVORA_KEYSTORE_PASSWORD")
    val hasReleaseKey = !releaseKeystore.isNullOrBlank() && !releasePassword.isNullOrBlank()

    signingConfigs {
        if (hasReleaseKey) {
            create("release") {
                storeFile = file(releaseKeystore!!)
                storePassword = releasePassword
                keyAlias = System.getenv("AVORA_KEY_ALIAS") ?: "avora"
                keyPassword = releasePassword
            }
        }
    }

    buildTypes {
        release {
            isDebuggable = false
            if (hasReleaseKey) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
