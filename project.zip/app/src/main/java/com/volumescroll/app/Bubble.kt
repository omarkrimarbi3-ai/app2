package com.volumescroll.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.min

/**
 * The floating shortcut. It is drawn by the accessibility service as an accessibility overlay,
 * so it needs no "display over other apps" permission and no notification.
 */
class BubbleController(private val service: VolumeScrollService) {

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val slop = ViewConfiguration.get(service).scaledTouchSlop

    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var menu: View? = null
    private var detector: GestureDetector? = null

    private fun dp(v: Float): Float = v * service.resources.displayMetrics.density
    private fun dpi(v: Int): Int = dp(v.toFloat()).toInt()

    /** Shows, updates or hides the bubble according to the current settings. */
    fun sync() {
        val cfg = Prefs.bubble()
        if (!Prefs.enabled || !cfg.enabled) {
            remove()
            return
        }
        try {
            show(cfg)
        } catch (e: Exception) {
            // The system refused the overlay: keep the rest of the service working.
        }
    }

    fun remove() {
        closeMenu()
        val view = bubble
        if (view != null) {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
                // Already removed.
            }
        }
        bubble = null
        bubbleParams = null
    }

    private fun show(cfg: BubbleCfg) {
        val dm = service.resources.displayMetrics
        val size = dpi(cfg.sizeDp)
        val w = if (cfg.shape == BubbleShape.CAPSULE) (size * 1.6f).toInt() else size
        val h = size

        val view = bubble ?: createBubbleView().also { bubble = it }
        val params = bubbleParams ?: WindowManager.LayoutParams(
            w,
            h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).also {
            it.gravity = Gravity.TOP or Gravity.START
            bubbleParams = it
        }
        params.width = w
        params.height = h
        params.x = if (cfg.right) dm.widthPixels - w else 0
        params.y = ((dm.heightPixels - h) * cfg.yPct / 100f).toInt()

        val bg = GradientDrawable()
        bg.setColor(BubbleStyle.COLORS[cfg.colorIdx.coerceIn(0, BubbleStyle.COLORS.size - 1)])
        bg.cornerRadius = when (cfg.shape) {
            BubbleShape.CIRCLE -> h / 2f
            BubbleShape.ROUNDED -> h * 0.3f
            BubbleShape.CAPSULE -> h / 2f
        }
        bg.setStroke(dpi(2), 0x55FFFFFF)
        view.background = bg
        view.text = cfg.emoji
        view.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.46f)
        view.alpha = cfg.alphaPct / 100f
        detector = buildDetector(cfg.trigger)

        if (view.parent == null) wm.addView(view, params) else wm.updateViewLayout(view, params)
    }

    private fun createBubbleView(): TextView {
        val view = TextView(service)
        view.gravity = Gravity.CENTER
        view.includeFontPadding = false

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false

        view.setOnTouchListener { v, e ->
            detector?.onTouchEvent(e)
            val params = bubbleParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params?.x ?: 0
                    startY = params?.y ?: 0
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging && params != null) {
                        val dm = service.resources.displayMetrics
                        params.x = (startX + dx).toInt().coerceIn(0, (dm.widthPixels - params.width).coerceAtLeast(0))
                        params.y = (startY + dy).toInt().coerceIn(0, (dm.heightPixels - params.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(v, params)
                        } catch (ex: Exception) {
                            // View was removed while dragging.
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        snapAndSave()
                    }
                }
            }
            true
        }
        return view
    }

    /** After a drag: stick to the nearest side, remember the position. */
    private fun snapAndSave() {
        val p = bubbleParams ?: return
        val dm = service.resources.displayMetrics
        val right = p.x + p.width / 2 > dm.widthPixels / 2
        val range = (dm.heightPixels - p.height).coerceAtLeast(1)
        val yPct = (p.y * 100f / range).toInt().coerceIn(0, 100)
        Prefs.saveBubble(Prefs.bubble().copy(right = right, yPct = yPct))
        sync()
    }

    private fun buildDetector(trigger: BubbleTrigger): GestureDetector {
        val listener = object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (trigger == BubbleTrigger.TAP) openMenu()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (trigger == BubbleTrigger.DOUBLE) openMenu()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (trigger == BubbleTrigger.LONG) openMenu()
            }
        }
        val d = GestureDetector(service, listener)
        d.setIsLongpressEnabled(trigger == BubbleTrigger.LONG)
        return d
    }

    // ---- Shortcut menu ----------------------------------------------------------------------

    private fun openMenu() {
        if (menu != null) return
        val ctx = Lang.wrap(service)
        val items = Prefs.bubbleShortcuts()
        val dm = service.resources.displayMetrics

        val scrim = FrameLayout(service)
        scrim.setBackgroundColor(0x88000000.toInt())
        scrim.setOnClickListener { closeMenu() }

        val card = LinearLayout(service)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dpi(12), dpi(12), dpi(12), dpi(12))
        card.isClickable = true
        val cardBg = GradientDrawable()
        cardBg.setColor(0xFF1F1F29.toInt())
        cardBg.cornerRadius = dp(28f)
        card.background = cardBg

        if (items.isEmpty()) {
            val empty = TextView(service)
            empty.text = ctx.getString(R.string.bubble_menu_empty)
            empty.setTextColor(Color.WHITE)
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            empty.setPadding(dpi(12), dpi(12), dpi(12), dpi(12))
            empty.maxWidth = (dm.widthPixels * 0.7f).toInt()
            card.addView(empty)
        } else {
            val cols = min(4, items.size)
            val cellW = dpi(76)
            val cellH = dpi(88)
            val grid = LinearLayout(service)
            grid.orientation = LinearLayout.VERTICAL
            items.chunked(cols).forEach { rowItems ->
                val row = LinearLayout(service)
                row.orientation = LinearLayout.HORIZONTAL
                rowItems.forEach { row.addView(cell(ctx, it, cellW, cellH)) }
                grid.addView(row)
            }
            val rows = ceil(items.size / cols.toDouble()).toInt()
            val maxH = (dm.heightPixels * 0.6f).toInt()
            val scroll = ScrollView(service)
            scroll.addView(grid)
            card.addView(scroll, LinearLayout.LayoutParams(cols * cellW, min(rows * cellH, maxH)))
        }

        scrim.addView(
            card,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
        )

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        try {
            wm.addView(scrim, params)
            menu = scrim
        } catch (e: Exception) {
            // Could not show the menu.
        }
    }

    private fun cell(ctx: Context, s: Shortcut, w: Int, h: Int): View {
        val col = LinearLayout(service)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.layoutParams = LinearLayout.LayoutParams(w, h)
        col.setPadding(dpi(4), dpi(8), dpi(4), dpi(4))

        var icon: View? = null
        val pkg = s.action.arg
        if (s.emoji == null && s.action.type == ActionType.OPEN_APP && pkg != null) {
            try {
                val image = ImageView(service)
                image.setImageDrawable(service.packageManager.getApplicationIcon(pkg))
                icon = image
            } catch (e: Exception) {
                icon = null
            }
        }
        if (icon == null) {
            val emoji = TextView(service)
            emoji.text = s.emoji ?: s.action.type.emoji
            emoji.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
            emoji.gravity = Gravity.CENTER
            icon = emoji
        }
        col.addView(icon, LinearLayout.LayoutParams(dpi(44), dpi(44)))

        val label = TextView(service)
        label.text = s.displayName(ctx)
        label.setTextColor(Color.WHITE)
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        label.gravity = Gravity.CENTER
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dpi(4)
        col.addView(label, lp)

        col.setOnClickListener {
            closeMenu()
            handler.post { ActionExecutor.execute(service, s.action, 0) }
        }
        return col
    }

    private fun closeMenu() {
        val view = menu ?: return
        menu = null
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // Already removed.
        }
    }
}
