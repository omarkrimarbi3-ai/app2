package com.volumescroll.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.min

/**
 * The floating shortcut. It is drawn by the accessibility service as an accessibility overlay,
 * so it needs no "display over other apps" permission and no notification.
 */
class BubbleController(private val service: VolumeScrollService) {

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val slop = ViewConfiguration.get(service).scaledTouchSlop

    private var bubble: TextView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var menu: View? = null
    private var detector: GestureDetector? = null

    private fun dp(v: Float): Float = v * service.resources.displayMetrics.density
    private fun dpi(v: Int): Int = dp(v.toFloat()).toInt()

    /** Shows, updates or hides the bubble according to the current settings. */
    fun sync() {
        val cfg = Prefs.bubble()
        if (!Prefs.enabled || !cfg.enabled) {
            remove()
            return
        }
        try {
            show(cfg)
        } catch (e: Exception) {
            // The system refused the overlay: keep the rest of the service working.
        }
    }

    fun remove() {
        closeMenu()
        val view = bubble
        if (view != null) {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
                // Already removed.
            }
        }
        bubble = null
        bubbleParams = null
    }

    private fun show(cfg: BubbleCfg) {
        val dm = service.resources.displayMetrics
        val size = dpi(cfg.sizeDp)
        val w = if (cfg.shape == BubbleShape.CAPSULE) (size * 1.6f).toInt() else size
        val h = size

        val view = bubble ?: createBubbleView().also { bubble = it }
        val params = bubbleParams ?: WindowManager.LayoutParams(
            w,
            h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).also {
            it.gravity = Gravity.TOP or Gravity.START
            bubbleParams = it
        }
        params.width = w
        params.height = h
        params.x = if (cfg.right) dm.widthPixels - w else 0
        params.y = ((dm.heightPixels - h) * cfg.yPct / 100f).toInt()

        val bg = GradientDrawable()
        bg.setColor(BubbleStyle.COLORS[cfg.colorIdx.coerceIn(0, BubbleStyle.COLORS.size - 1)])
        bg.cornerRadius = when (cfg.shape) {
            BubbleShape.CIRCLE -> h / 2f
            BubbleShape.ROUNDED -> h * 0.3f
            BubbleShape.CAPSULE -> h / 2f
        }
        bg.setStroke(dpi(2), 0x55FFFFFF)
        view.background = bg
        view.text = cfg.emoji
        view.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.46f)
        view.alpha = cfg.alphaPct / 100f
        detector = buildDetector(cfg.trigger)

        if (view.parent == null) wm.addView(view, params) else wm.updateViewLayout(view, params)
    }

    private fun createBubbleView(): TextView {
        val view = TextView(service)
        view.gravity = Gravity.CENTER
        view.includeFontPadding = false

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false

        view.setOnTouchListener { v, e ->
            detector?.onTouchEvent(e)
            val params = bubbleParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params?.x ?: 0
                    startY = params?.y ?: 0
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging && params != null) {
                        val dm = service.resources.displayMetrics
                        params.x = (startX + dx).toInt().coerceIn(0, (dm.widthPixels - params.width).coerceAtLeast(0))
                        params.y = (startY + dy).toInt().coerceIn(0, (dm.heightPixels - params.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(v, params)
                        } catch (ex: Exception) {
                            // View was removed while dragging.
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        snapAndSave()
                    }
                }
            }
            true
        }
        return view
    }

    /** After a drag: stick to the nearest side, remember the position. */
    private fun snapAndSave() {
        val p = bubbleParams ?: return
        val dm = service.resources.displayMetrics
        val right = p.x + p.width / 2 > dm.widthPixels / 2
        val range = (dm.heightPixels - p.height).coerceAtLeast(1)
        val yPct = (p.y * 100f / range).toInt().coerceIn(0, 100)
        Prefs.saveBubble(Prefs.bubble().copy(right = right, yPct = yPct))
        sync()
    }

    private fun buildDetector(trigger: BubbleTrigger): GestureDetector {
        val listener = object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (trigger == BubbleTrigger.TAP) openMenu()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (trigger == BubbleTrigger.DOUBLE) openMenu()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (trigger == BubbleTrigger.LONG) openMenu()
            }
        }
        val d = GestureDetector(service, listener)
        d.setIsLongpressEnabled(trigger == BubbleTrigger.LONG)
        return d
    }

    // ---- Shortcut menu ----------------------------------------------------------------------

    private fun openMenu() {
        if (menu != null) return
        val bubbleView = bubble ?: return
        val ctx = Lang.wrap(service)
        val items = Prefs.bubbleShortcuts()

        val scrim = FrameLayout(service)
        scrim.setBackgroundColor(0x77000000)
        scrim.setOnClickListener { closeMenu() }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        // Place the items once the scrim has been laid out, using real screen coordinates.
        var placed = false
        val right = Prefs.bubble().right
        scrim.addOnLayoutChangeListener { _, l, t, r, bt, _, _, _, _ ->
            if (placed || r - l <= 0 || bt - t <= 0) return@addOnLayoutChangeListener
            placed = true
            try {
                val own = IntArray(2)
                scrim.getLocationOnScreen(own)
                val loc = IntArray(2)
                bubbleView.getLocationOnScreen(loc)
                val cx = loc[0] - own[0] + bubbleView.width / 2f
                val cy = loc[1] - own[1] + bubbleView.height / 2f
                layoutRadial(scrim, ctx, items, cx, cy, r - l, bt - t, right)
            } catch (e: Exception) {
                placed = false
            }
        }
        // Safety net: if the layout callback did not place anything, use the bubble's own position.
        handler.postDelayed({
            if (!placed && menu === scrim) {
                placed = true
                try {
                    val dm = service.resources.displayMetrics
                    val p = bubbleParams
                    val cx = (p?.x ?: 0) + (p?.width ?: 0) / 2f
                    val cy = (p?.y ?: 0) + (p?.height ?: 0) / 2f
                    layoutRadial(scrim, ctx, items, cx, cy, dm.widthPixels, dm.heightPixels, right)
                } catch (e: Exception) {
                    closeMenu()
                }
            }
        }, 350L)

        try {
            wm.addView(scrim, params)
            menu = scrim
        } catch (e: Exception) {
            // Could not show the menu.
        }
    }

    /** Puts the shortcuts on circles around the bubble, like the quick ball of Xiaomi phones. */
    private fun layoutRadial(
        scrim: FrameLayout,
        ctx: Context,
        items: List<Shortcut>,
        cx: Float,
        cy: Float,
        width: Int,
        height: Int,
        right: Boolean
    ) {
        scrim.removeAllViews()
        val itemSize = dpi(52)
        val margin = itemSize / 2f + dp(8f)

        // Centre button: closes the menu (the bubble itself sits under the dimmed layer).
        val centerSize = dpi(Prefs.bubble().sizeDp.coerceAtMost(60))
        val close = TextView(service)
        close.text = "✕"
        close.setTextColor(Color.WHITE)
        close.setTextSize(TypedValue.COMPLEX_UNIT_PX, centerSize * 0.4f)
        close.gravity = Gravity.CENTER
        val closeBg = GradientDrawable()
        closeBg.setColor(0xFF16161F.toInt())
        closeBg.shape = GradientDrawable.OVAL
        closeBg.setStroke(dpi(2), 0x55FFFFFF)
        close.background = closeBg
        close.elevation = dp(8f)
        close.setOnClickListener { closeMenu() }
        place(scrim, close, centerSize, cx, cy)

        if (items.isEmpty()) {
            val empty = TextView(service)
            empty.text = ctx.getString(R.string.bubble_menu_empty)
            empty.setTextColor(Color.BLACK)
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            empty.setPadding(dpi(16), dpi(12), dpi(16), dpi(12))
            empty.maxWidth = (width * 0.6f).toInt()
            val bg = GradientDrawable()
            bg.setColor(Color.WHITE)
            bg.cornerRadius = dp(18f)
            empty.background = bg
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
            scrim.addView(empty, lp)
            return
        }

        // Slots on rings, facing the inside of the screen.
        val baseAngle = if (right) Math.PI else 0.0
        var remaining = items.size
        var index = 0
        var ring = 0
        while (remaining > 0 && ring < 6) {
            val radius = dp(86f) + ring * dp(60f)
            val count = (Math.PI * radius / dp(60f)).toInt() + 1
            val slots = ArrayList<FloatArray>()
            for (j in 0 until count) {
                val phi = -Math.PI / 2 + Math.PI * j / (count - 1).coerceAtLeast(1)
                val x = cx + (radius * Math.cos(baseAngle + phi)).toFloat()
                val y = cy + (radius * Math.sin(baseAngle + phi)).toFloat()
                if (x >= margin && x <= width - margin && y >= margin && y <= height - margin) {
                    slots.add(floatArrayOf(x, y))
                }
            }
            val take = min(remaining, slots.size)
            for (k in 0 until take) {
                val slot = if (take == slots.size) {
                    slots[k]
                } else if (take == 1) {
                    slots[slots.size / 2]
                } else {
                    slots[Math.round(k * (slots.size - 1) / (take - 1).toFloat())]
                }
                val view = itemView(ctx, items[index], itemSize)
                place(scrim, view, itemSize, slot[0], slot[1])
                view.translationX = cx - slot[0]
                view.translationY = cy - slot[1]
                view.scaleX = 0.3f
                view.scaleY = 0.3f
                view.alpha = 0f
                view.animate()
                    .translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                    .setStartDelay((index * 18L))
                    .setDuration(200L)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.2f))
                    .start()
                index++
                remaining--
            }
            ring++
        }
    }

    private fun place(parent: FrameLayout, view: View, size: Int, centerX: Float, centerY: Float) {
        val lp = FrameLayout.LayoutParams(size, size)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = (centerX - size / 2f).toInt()
        lp.topMargin = (centerY - size / 2f).toInt()
        parent.addView(view, lp)
    }

    private fun itemView(ctx: Context, s: Shortcut, size: Int): View {
        val box = FrameLayout(service)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.WHITE)
        box.background = bg
        box.elevation = dp(8f)
        box.contentDescription = s.displayName(ctx)

        var icon: View? = null
        val pkg = s.action.arg
        if (s.emoji == null && s.action.type == ActionType.OPEN_APP && pkg != null) {
            try {
                val image = ImageView(service)
                image.setImageDrawable(service.packageManager.getApplicationIcon(pkg))
                icon = image
            } catch (e: Exception) {
                icon = null
            }
        }
        if (icon == null) {
            val emoji = TextView(service)
            emoji.text = s.emoji ?: s.action.type.emoji
            emoji.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * 0.5f)
            emoji.gravity = Gravity.CENTER
            emoji.includeFontPadding = false
            icon = emoji
        }
        val inner = (size * 0.64f).toInt()
        val lp = FrameLayout.LayoutParams(inner, inner, Gravity.CENTER)
        box.addView(icon, lp)

        box.setOnClickListener {
            closeMenu()
            handler.post { ActionExecutor.execute(service, s.action, 0) }
        }
        return box
    }

    private fun closeMenu() {
        val view = menu ?: return
        menu = null
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // Already removed.
        }
    }
}
