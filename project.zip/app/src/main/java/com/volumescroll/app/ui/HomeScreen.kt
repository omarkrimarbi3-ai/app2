package com.volumescroll.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState

enum class Dest { BUTTONS, BUBBLE, QUICK, PROFILES, RULES, SETTINGS }

@Composable
fun HomeScreen(
    state: SettingsState,
    serviceOn: Boolean,
    onOpenAccessibility: () -> Unit,
    onNavigate: (Dest) -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Header()

        // Profiles: one tap to switch.
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            state.profiles.forEach { p ->
                PillChip(
                    label = p.emoji + " " + p.displayName(context),
                    selected = p.id == state.activeId
                ) { state.switchProfile(p.id) }
            }
        }

        PowerCard(
            serviceOn = serviceOn,
            enabled = state.enabled,
            onClick = {
                if (!serviceOn) onOpenAccessibility() else state.changeEnabled(!state.enabled)
            }
        )

        if (!serviceOn) {
            OutlinedButton(
                onClick = { onNavigate(Dest.SETTINGS) },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) { Text(stringResource(R.string.home_help_enable)) }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HubCard(
                emoji = "🎛️",
                title = stringResource(R.string.hub_buttons),
                subtitle = stringResource(R.string.hub_buttons_sub),
                colors = listOf(Accent.Violet, Accent.VioletDark),
                modifier = Modifier.weight(1f)
            ) { onNavigate(Dest.BUTTONS) }
            HubCard(
                emoji = "🫧",
                title = stringResource(R.string.hub_bubble),
                subtitle = stringResource(R.string.hub_bubble_sub),
                colors = listOf(Accent.Pink, Accent.PinkDark),
                modifier = Modifier.weight(1f)
            ) { onNavigate(Dest.BUBBLE) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HubCard(
                emoji = "⚡",
                title = stringResource(R.string.hub_quick),
                subtitle = stringResource(R.string.hub_quick_sub),
                colors = listOf(Accent.Orange, Accent.OrangeDark),
                modifier = Modifier.weight(1f)
            ) { onNavigate(Dest.QUICK) }
            HubCard(
                emoji = "👤",
                title = stringResource(R.string.hub_profiles),
                subtitle = stringResource(R.string.hub_profiles_sub),
                colors = listOf(Accent.Teal, Accent.TealDark),
                modifier = Modifier.weight(1f)
            ) { onNavigate(Dest.PROFILES) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HubCard(
                emoji = "📱",
                title = stringResource(R.string.hub_rules),
                subtitle = stringResource(R.string.hub_rules_sub),
                colors = listOf(Accent.Blue, Accent.BlueDark),
                modifier = Modifier.weight(1f)
            ) { onNavigate(Dest.RULES) }
            HubCard(
                emoji = "⚙️",
                title = stringResource(R.string.hub_settings),
                subtitle = stringResource(R.string.hub_settings_sub),
                colors = listOf(Accent.Green, Accent.GreenDark),
                modifier = Modifier.weight(1f)
            ) { onNavigate(Dest.SETTINGS) }
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Image(
            painter = painterResource(R.drawable.ic_logo),
            contentDescription = null,
            modifier = Modifier.size(52.dp)
        )
        Column {
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                stringResource(R.string.tagline),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PowerCard(serviceOn: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val active = serviceOn && enabled
    val colors = when {
        !serviceOn -> listOf(Accent.Orange, Accent.Pink)
        !enabled -> listOf(Accent.Slate, Accent.SlateLight)
        else -> listOf(Accent.Green, Accent.Teal)
    }
    val title = when {
        !serviceOn -> R.string.status_setup
        !enabled -> R.string.status_off
        else -> R.string.status_active
    }
    val hint = when {
        !serviceOn -> R.string.status_setup_hint
        !enabled -> R.string.status_off_hint
        else -> R.string.status_active_hint
    }

    GradientCard(colors = colors, modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ArrowsGlyph(Color.White.copy(alpha = if (active) 1f else 0.85f))
            Text(
                stringResource(title),
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                stringResource(hint),
                color = Color.White.copy(alpha = 0.9f),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun ArrowsGlyph(color: Color) {
    Canvas(Modifier.size(56.dp)) {
        val w = size.width
        val h = size.height
        val up = Path().apply {
            moveTo(w * 0.5f, h * 0.04f)
            lineTo(w * 0.86f, h * 0.46f)
            lineTo(w * 0.14f, h * 0.46f)
            close()
        }
        val down = Path().apply {
            moveTo(w * 0.5f, h * 0.96f)
            lineTo(w * 0.14f, h * 0.54f)
            lineTo(w * 0.86f, h * 0.54f)
            close()
        }
        drawPath(up, color)
        drawPath(down, color)
    }
}

@Composable
private fun HubCard(
    emoji: String,
    title: String,
    subtitle: String,
    colors: List<Color>,
    modifier: Modifier,
    onClick: () -> Unit
) {
    GradientCard(colors = colors, modifier = modifier.height(156.dp), onClick = onClick) {
        Text(emoji, fontSize = 30.sp)
        Spacer(Modifier.weight(1f))
        Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(
            subtitle,
            color = Color.White.copy(alpha = 0.88f),
            fontSize = 12.sp,
            lineHeight = 16.sp
        )
    }
}
