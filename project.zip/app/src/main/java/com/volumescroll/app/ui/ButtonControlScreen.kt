package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.volumescroll.app.ActionExecutor
import com.volumescroll.app.Btn
import com.volumescroll.app.Gest
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState
import com.volumescroll.app.Source

internal fun btnName(btn: Btn): Int =
    if (btn == Btn.UP) R.string.bc_vol_up else R.string.bc_vol_down

internal fun gestName(gest: Gest): Int = when (gest) {
    Gest.SINGLE -> R.string.bc_single
    Gest.LONG -> R.string.bc_long
    Gest.DOUBLE -> R.string.bc_double
}

/**
 * Button settings for one [source]: the selected-apps group, every other app, or one app rule.
 * With [showTabs] the user can switch between the first two.
 */
@Composable
fun ButtonControlScreen(
    state: SettingsState,
    title: String,
    source: Source,
    showTabs: Boolean,
    onSourceChange: (Source) -> Unit,
    onPick: (Btn, Gest) -> Unit,
    onChooseApps: () -> Unit,
    onDeleteRule: (() -> Unit)?,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(title, state.activeProfile.emoji + " " + state.activeProfile.displayName(context), onBack)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (showTabs) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillChip(
                        label = stringResource(R.string.bc_scope_apps),
                        selected = source == Source.Selected,
                        modifier = Modifier.weight(1f)
                    ) { onSourceChange(Source.Selected) }
                    PillChip(
                        label = stringResource(R.string.bc_scope_other),
                        selected = source == Source.Others,
                        modifier = Modifier.weight(1f)
                    ) { onSourceChange(Source.Others) }
                }
            }

            val descRes = when (source) {
                Source.Selected -> R.string.bc_scope_apps_desc
                Source.Others -> R.string.bc_scope_other_desc
                is Source.App -> R.string.bc_scope_app_desc
            }
            HintText(stringResource(descRes))

            if (source == Source.Selected) {
                SectionCard {
                    SectionTitle(stringResource(R.string.bc_apps_group))
                    HintText("${state.apps.size} " + stringResource(R.string.stat_apps))
                    Button(
                        onClick = onChooseApps,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text(stringResource(R.string.apps_choose), fontWeight = FontWeight.SemiBold) }
                }
            }

            if (source == Source.Others &&
                Btn.values().any { !state.gestures(Source.Others, it).isPassThrough }
            ) {
                Text(
                    stringResource(R.string.bc_warn_other),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = cs.error
                )
            }

            Btn.values().forEach { btn ->
                SectionCard {
                    SectionTitle(stringResource(btnName(btn)))
                    Gest.values().forEach { gest ->
                        val ref = state.action(source, btn, gest)
                        GestureRow(
                            title = stringResource(gestName(gest)),
                            value = ActionExecutor.label(context, ref, gest == Gest.SINGLE)
                        ) { onPick(btn, gest) }
                    }
                }
            }

            HintText(stringResource(R.string.bc_notes))

            OutlinedButton(
                onClick = { state.resetButtons(source) },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(stringResource(R.string.bc_reset)) }

            if (onDeleteRule != null) {
                OutlinedButton(
                    onClick = onDeleteRule,
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(stringResource(R.string.rule_delete)) }
            }
        }
    }
}

@Composable
private fun GestureRow(title: String, value: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            title,
            modifier = Modifier.weight(1f),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold
        )
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = cs.primaryContainer,
            contentColor = cs.onPrimaryContainer,
            border = BorderStroke(1.dp, cs.outlineVariant)
        ) {
            Text(
                value,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
