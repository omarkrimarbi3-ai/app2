package com.volumescroll.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.media.AudioManager
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Intercepts the physical volume keys (via flagRequestFilterKeyEvents / onKeyEvent) and turns
 * them into swipe gestures, but only while one of the user's selected apps is in the foreground.
 */
class VolumeScrollService : AccessibilityService() {

    @Volatile private var currentPackage: String? = null
    private var ignoredPackages: Set<String> = setOf("com.android.systemui")

    private var lastScrollAt = 0L
    private var gestureInFlight = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        Prefs.init(this)
        refreshIgnoredPackages()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in ignoredPackages) return
        currentPackage = pkg
    }

    override fun onInterrupt() = Unit

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (!Prefs.enabled) return false
        if (isInCall()) return false
        val pkg = currentPackage ?: return false
        if (pkg !in Prefs.apps) return false

        // Consume both DOWN and UP so the system never changes the volume in selected apps.
        if (event.action == KeyEvent.ACTION_DOWN) {
            val towardsEnd = (code == KeyEvent.KEYCODE_VOLUME_DOWN) != Prefs.reverse
            performScroll(towardsEnd)
        }
        return true
    }

    private fun performScroll(towardsEnd: Boolean) {
        val speed = Prefs.speed
        val distanceFraction = when (speed) {
            1 -> 0.25f; 2 -> 0.32f; 3 -> 0.40f; 4 -> 0.50f; else -> 0.60f
        }
        val durationMs = when (speed) {
            1 -> 450L; 2 -> 350L; 3 -> 260L; 4 -> 190L; else -> 130L
        }

        val now = SystemClock.uptimeMillis()
        if (gestureInFlight && now - lastScrollAt < 1000L) return
        if (now - lastScrollAt < durationMs + 40L) return

        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val centerY = dm.heightPixels / 2f
        val half = dm.heightPixels * distanceFraction / 2f

        // Scrolling towards the end of the content = finger swipes upwards.
        val startY = if (towardsEnd) centerY + half else centerY - half
        val endY = if (towardsEnd) centerY - half else centerY + half

        val path = Path().apply {
            moveTo(x, startY)
            lineTo(x, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, durationMs))
            .build()

        gestureInFlight = true
        lastScrollAt = now
        val accepted = dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                gestureInFlight = false
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                gestureInFlight = false
            }
        }, null)
        if (!accepted) gestureInFlight = false
    }

    private fun isInCall(): Boolean {
        val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return false
        return am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION
    }

    /** Keyboards and the system UI open windows too; they must not replace the foreground app. */
    private fun refreshIgnoredPackages() {
        val set = mutableSetOf("com.android.systemui")
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.enabledInputMethodList?.forEach { set.add(it.packageName) }
        ignoredPackages = set
    }
}
