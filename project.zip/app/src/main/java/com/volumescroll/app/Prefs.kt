package com.volumescroll.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Single source of truth for settings. Initialised once from [VolumeScrollApp]. */
object Prefs {
    private const val FILE = "volume_scroll_prefs"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_SPEED = "speed"
    private const val KEY_REVERSE = "reverse"
    private const val KEY_APPS = "apps"

    const val MIN_SPEED = 1
    const val MAX_SPEED = 5

    private lateinit var sp: SharedPreferences

    fun init(context: Context) {
        if (!::sp.isInitialized) {
            sp = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        }
    }

    var enabled: Boolean
        get() = sp.getBoolean(KEY_ENABLED, false)
        set(v) = sp.edit().putBoolean(KEY_ENABLED, v).apply()

    var speed: Int
        get() = sp.getInt(KEY_SPEED, 3).coerceIn(MIN_SPEED, MAX_SPEED)
        set(v) = sp.edit().putInt(KEY_SPEED, v.coerceIn(MIN_SPEED, MAX_SPEED)).apply()

    var reverse: Boolean
        get() = sp.getBoolean(KEY_REVERSE, false)
        set(v) = sp.edit().putBoolean(KEY_REVERSE, v).apply()

    /** Package names where volume buttons act as scroll buttons. Treat as read-only. */
    var apps: Set<String>
        get() = sp.getStringSet(KEY_APPS, emptySet()) ?: emptySet()
        set(v) = sp.edit().putStringSet(KEY_APPS, HashSet(v)).apply()
}

/** Compose-observable mirror of [Prefs]; call [refresh] when the screen resumes. */
class SettingsState {
    var enabled by mutableStateOf(Prefs.enabled); private set
    var speed by mutableIntStateOf(Prefs.speed); private set
    var reverse by mutableStateOf(Prefs.reverse); private set
    var apps by mutableStateOf(Prefs.apps); private set

    fun refresh() {
        enabled = Prefs.enabled
        speed = Prefs.speed
        reverse = Prefs.reverse
        apps = Prefs.apps
    }

    fun setEnabled(v: Boolean) { Prefs.enabled = v; enabled = v }
    fun setSpeed(v: Int) { Prefs.speed = v; speed = Prefs.speed }
    fun setReverse(v: Boolean) { Prefs.reverse = v; reverse = v }

    fun toggleApp(pkg: String) {
        val next = apps.toMutableSet()
        if (!next.add(pkg)) next.remove(pkg)
        Prefs.apps = next
        apps = next
    }
}
