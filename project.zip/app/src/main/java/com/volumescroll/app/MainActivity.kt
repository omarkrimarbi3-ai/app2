package com.volumescroll.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.volumescroll.app.ui.AppsScreen
import com.volumescroll.app.ui.MainScreen
import com.volumescroll.app.ui.VolumeScrollTheme

class MainActivity : ComponentActivity() {

    private lateinit var state: SettingsState
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        state = SettingsState()

        setContent {
            VolumeScrollTheme {
                var showApps by remember { mutableStateOf(false) }
                val serviceOn = remember(resumeTick.intValue) { isAccessibilityEnabled(this) }

                if (showApps) {
                    AppsScreen(state = state, onBack = { showApps = false })
                } else {
                    MainScreen(
                        state = state,
                        serviceOn = serviceOn,
                        onOpenAccessibility = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                        onOpenAppInfo = {
                            startActivity(
                                Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", packageName, null)
                                )
                            )
                        },
                        onPickApps = { showApps = true }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        state.refresh()
        resumeTick.intValue++
    }

    private fun isAccessibilityEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val mine = ComponentName(context, VolumeScrollService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == mine }
    }
}
