package com.volumescroll.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.volumescroll.app.Prefs
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState
import kotlin.math.roundToInt

@Composable
fun MainScreen(
    state: SettingsState,
    serviceOn: Boolean,
    onOpenAccessibility: () -> Unit,
    onOpenAppInfo: () -> Unit,
    onPickApps: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Header()

        PowerCard(
            serviceOn = serviceOn,
            enabled = state.enabled,
            onClick = {
                if (!serviceOn) onOpenAccessibility() else state.changeEnabled(!state.enabled)
            }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard(
                label = stringResource(R.string.stat_apps),
                value = state.apps.size.toString(),
                modifier = Modifier.weight(1f),
                onClick = onPickApps
            )
            StatCard(
                label = stringResource(R.string.stat_speed),
                value = "${state.speed}/${Prefs.MAX_SPEED}",
                modifier = Modifier.weight(1f),
                onClick = null
            )
        }

        // Apps
        SectionCard {
            SectionTitle(stringResource(R.string.apps_title))
            Text(
                stringResource(R.string.apps_hint),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = onPickApps,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(stringResource(R.string.apps_choose), fontWeight = FontWeight.SemiBold) }
        }

        // Speed
        SectionCard {
            SectionTitle(stringResource(R.string.speed_title))
            Text(
                stringResource(R.string.speed_desc),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Slider(
                value = state.speed.toFloat(),
                onValueChange = { state.changeSpeed(it.roundToInt()) },
                valueRange = Prefs.MIN_SPEED.toFloat()..Prefs.MAX_SPEED.toFloat(),
                steps = Prefs.MAX_SPEED - Prefs.MIN_SPEED - 1
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stringResource(R.string.speed_slow), style = MaterialTheme.typography.labelMedium)
                Text(stringResource(R.string.speed_fast), style = MaterialTheme.typography.labelMedium)
            }
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        stringResource(R.string.reverse_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        stringResource(R.string.reverse_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = state.reverse, onCheckedChange = { state.changeReverse(it) })
            }
        }

        // How to use
        SectionCard {
            SectionTitle(stringResource(R.string.howto_title))
            listOf(R.string.howto_1, R.string.howto_2, R.string.howto_3, R.string.howto_4).forEach {
                Text(stringResource(it), style = MaterialTheme.typography.bodyMedium)
            }
        }

        // Permissions
        SectionCard {
            SectionTitle(stringResource(R.string.perm_title))
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    stringResource(R.string.perm_a11y_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    stringResource(if (serviceOn) R.string.perm_on else R.string.perm_off),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                stringResource(R.string.perm_a11y_why),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = onOpenAccessibility,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(stringResource(R.string.perm_open), fontWeight = FontWeight.SemiBold) }

            if (!serviceOn) {
                Text(
                    stringResource(R.string.perm_restricted_title),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 8.dp)
                )
                Text(
                    stringResource(R.string.perm_restricted_body),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = onOpenAppInfo,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(stringResource(R.string.perm_restricted_open)) }
            }
            Text(
                stringResource(R.string.perm_none),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Limits
        SectionCard {
            SectionTitle(stringResource(R.string.limits_title))
            Text(stringResource(R.string.limits_body), style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Image(
            painter = painterResource(R.drawable.ic_logo),
            contentDescription = null,
            modifier = Modifier.size(52.dp)
        )
        Column {
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                stringResource(R.string.tagline),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PowerCard(serviceOn: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val active = serviceOn && enabled
    val container = if (active) cs.primary else cs.surfaceVariant
    val content = if (active) cs.onPrimary else cs.onSurface

    val (title, hint) = when {
        !serviceOn -> R.string.status_setup to R.string.status_setup_hint
        !enabled -> R.string.status_off to R.string.status_off_hint
        else -> R.string.status_active to R.string.status_active_hint
    }

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(32.dp),
        color = container,
        contentColor = content,
        border = if (active) null else BorderStroke(1.dp, cs.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ArrowsGlyph(color = content)
            Text(
                stringResource(title),
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                stringResource(hint),
                style = MaterialTheme.typography.bodyMedium,
                color = content.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
private fun ArrowsGlyph(color: Color) {
    Canvas(Modifier.size(64.dp)) {
        val w = size.width
        val h = size.height
        val up = Path().apply {
            moveTo(w * 0.5f, h * 0.04f)
            lineTo(w * 0.86f, h * 0.46f)
            lineTo(w * 0.14f, h * 0.46f)
            close()
        }
        val down = Path().apply {
            moveTo(w * 0.5f, h * 0.96f)
            lineTo(w * 0.14f, h * 0.54f)
            lineTo(w * 0.86f, h * 0.54f)
            close()
        }
        drawPath(up, color)
        drawPath(down, color)
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier, onClick: (() -> Unit)?) {
    val cs = MaterialTheme.colorScheme
    val body: @Composable () -> Unit = {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(value, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
    }
    if (onClick != null) {
        Surface(
            onClick = onClick,
            shape = RoundedCornerShape(24.dp),
            color = cs.surfaceVariant,
            border = BorderStroke(1.dp, cs.outline),
            modifier = modifier,
            content = body
        )
    } else {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = cs.surfaceVariant,
            border = BorderStroke(1.dp, cs.outline),
            modifier = modifier,
            content = body
        )
    }
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = cs.surfaceVariant,
        border = BorderStroke(1.dp, cs.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}
