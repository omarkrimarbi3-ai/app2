package com.volumescroll.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** The accent colours used by the cards. White text is always readable on these. */
object Accent {
    val Violet = Color(0xFF6D4AFF)
    val Pink = Color(0xFFE6397A)
    val Orange = Color(0xFFF0701E)
    val Teal = Color(0xFF0F9D8A)
    val Blue = Color(0xFF2F6FE4)
    val Green = Color(0xFF2E9E5B)
    val Slate = Color(0xFF475569)
    val SlateLight = Color(0xFF64748B)
    val VioletDark = Color(0xFF4A2FD0)
    val PinkDark = Color(0xFFC21E5C)
    val OrangeDark = Color(0xFFD4520A)
    val TealDark = Color(0xFF0A7A6B)
    val BlueDark = Color(0xFF1D52BD)
    val GreenDark = Color(0xFF1E7D44)
}

private val LightColors = lightColorScheme(
    primary = Accent.Violet,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE9E4FF),
    onPrimaryContainer = Color(0xFF2A1B8A),
    background = Color.White,
    onBackground = Color(0xFF14141F),
    surface = Color.White,
    onSurface = Color(0xFF14141F),
    surfaceVariant = Color(0xFFF3F3F8),
    onSurfaceVariant = Color(0xFF5B5B6B),
    outline = Color(0xFFE4E4EC),
    outlineVariant = Color(0xFFD0D0DC),
    error = Color(0xFFD92D20)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9B85FF),
    onPrimary = Color(0xFF120F2E),
    primaryContainer = Color(0xFF2E2570),
    onPrimaryContainer = Color(0xFFE9E4FF),
    background = Color(0xFF0C0C12),
    onBackground = Color(0xFFF2F2F7),
    surface = Color(0xFF0C0C12),
    onSurface = Color(0xFFF2F2F7),
    surfaceVariant = Color(0xFF1B1B25),
    onSurfaceVariant = Color(0xFFA8A8B8),
    outline = Color(0xFF2C2C38),
    outlineVariant = Color(0xFF3B3B4A),
    error = Color(0xFFFF6B5E)
)

@Composable
fun VolumeScrollTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, typography = Typography()) {
        Surface(color = colors.background, content = content)
    }
}
