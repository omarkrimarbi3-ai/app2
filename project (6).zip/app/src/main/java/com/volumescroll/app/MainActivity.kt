package com.volumescroll.app

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.volumescroll.app.ui.ActionPickerScreen
import com.volumescroll.app.ui.AppChooseScreen
import com.volumescroll.app.ui.AppRulesScreen
import com.volumescroll.app.ui.AppsScreen
import com.volumescroll.app.ui.BubbleScreen
import com.volumescroll.app.ui.ButtonControlScreen
import com.volumescroll.app.ui.Dest
import com.volumescroll.app.ui.HomeScreen
import com.volumescroll.app.ui.PickReq
import com.volumescroll.app.ui.ProfilesScreen
import com.volumescroll.app.ui.QuickActionsScreen
import com.volumescroll.app.ui.SettingsScreen
import com.volumescroll.app.ui.ShortcutEditScreen
import com.volumescroll.app.ui.VolumeScrollTheme
import com.volumescroll.app.ui.btnName
import com.volumescroll.app.ui.gestName

private sealed interface Screen {
    data object Home : Screen
    data object Buttons : Screen
    data object Apps : Screen
    data object Bubble : Screen
    data object Quick : Screen
    data object Profiles : Screen
    data object Rules : Screen
    data object Settings : Screen
    data class Rule(val pkg: String) : Screen
    data class ShortcutEdit(val id: String) : Screen
    data class Picker(val req: PickReq, val back: Screen) : Screen
    data class AppChoose(val onPick: (String) -> Unit, val back: Screen) : Screen
}

class MainActivity : ComponentActivity() {

    private lateinit var state: SettingsState
    private val resumeTick = mutableIntStateOf(0)

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(Lang.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        state = SettingsState()

        setContent {
            VolumeScrollTheme {
                var screen by remember { mutableStateOf<Screen>(Screen.Home) }
                var buttonSource by remember { mutableStateOf<Source>(Source.Selected) }
                val serviceOn = remember(resumeTick.intValue) { isAccessibilityEnabled(this) }

                fun openAccessibility() {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }

                fun pickerForButton(source: Source, btn: Btn, gest: Gest, back: Screen): Screen {
                    val single = gest == Gest.SINGLE
                    val req = PickReq(
                        title = getString(btnName(btn)) + " · " + getString(gestName(gest)),
                        current = state.action(source, btn, gest),
                        allowPass = true,
                        allowNone = true,
                        noneLabel = if (single) R.string.a_none_single else R.string.a_none,
                        noneDesc = if (single) R.string.a_none_single_desc else R.string.a_none_desc,
                        onResult = { ref -> state.changeAction(source, btn, gest, ref) }
                    )
                    return Screen.Picker(req, back)
                }

                when (val s = screen) {
                    Screen.Home -> HomeScreen(
                        state = state,
                        serviceOn = serviceOn,
                        onOpenAccessibility = { openAccessibility() },
                        onNavigate = { dest ->
                            screen = when (dest) {
                                Dest.BUTTONS -> Screen.Buttons
                                Dest.BUBBLE -> Screen.Bubble
                                Dest.QUICK -> Screen.Quick
                                Dest.PROFILES -> Screen.Profiles
                                Dest.RULES -> Screen.Rules
                                Dest.SETTINGS -> Screen.Settings
                            }
                        }
                    )

                    Screen.Settings -> SettingsScreen(
                        state = state,
                        serviceOn = serviceOn,
                        onOpenAccessibility = { openAccessibility() },
                        onOpenAppInfo = {
                            startActivity(
                                Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", packageName, null)
                                )
                            )
                        },
                        onLanguageChanged = { recreate() },
                        onBack = { screen = Screen.Home }
                    )

                    Screen.Apps -> AppsScreen(state = state, onBack = { screen = Screen.Buttons })

                    Screen.Buttons -> ButtonControlScreen(
                        state = state,
                        title = getString(R.string.bc_title),
                        source = buttonSource,
                        showTabs = true,
                        onSourceChange = { buttonSource = it },
                        onPick = { btn, gest ->
                            screen = pickerForButton(buttonSource, btn, gest, Screen.Buttons)
                        },
                        onChooseApps = { screen = Screen.Apps },
                        onDeleteRule = null,
                        onBack = { screen = Screen.Home }
                    )

                    is Screen.Rule -> ButtonControlScreen(
                        state = state,
                        title = ActionExecutor.appName(this, s.pkg) ?: s.pkg,
                        source = Source.App(s.pkg),
                        showTabs = false,
                        onSourceChange = { },
                        onPick = { btn, gest ->
                            screen = pickerForButton(Source.App(s.pkg), btn, gest, s)
                        },
                        onChooseApps = { },
                        onDeleteRule = {
                            state.removeRule(s.pkg)
                            screen = Screen.Rules
                        },
                        onBack = { screen = Screen.Rules }
                    )

                    Screen.Rules -> AppRulesScreen(
                        state = state,
                        onAdd = {
                            screen = Screen.AppChoose(
                                onPick = { pkg ->
                                    state.addRule(pkg)
                                    screen = Screen.Rule(pkg)
                                },
                                back = Screen.Rules
                            )
                        },
                        onOpen = { pkg -> screen = Screen.Rule(pkg) },
                        onBack = { screen = Screen.Home }
                    )

                    Screen.Bubble -> BubbleScreen(
                        state = state,
                        serviceOn = serviceOn,
                        onOpenQuick = { screen = Screen.Quick },
                        onOpenAccessibility = { openAccessibility() },
                        onBack = { screen = Screen.Home }
                    )

                    Screen.Quick -> QuickActionsScreen(
                        state = state,
                        onEdit = { id -> screen = Screen.ShortcutEdit(id) },
                        onAddCustom = {
                            val req = PickReq(
                                title = getString(R.string.qa_add_custom),
                                current = ActionRef(ActionType.NONE),
                                allowPass = false,
                                allowNone = false,
                                noneLabel = R.string.a_none,
                                noneDesc = R.string.a_none_desc,
                                onResult = { ref -> state.addShortcut(ref) }
                            )
                            screen = Screen.Picker(req, Screen.Quick)
                        },
                        onAddApp = {
                            screen = Screen.AppChoose(
                                onPick = { pkg ->
                                    state.addShortcut(ActionRef(ActionType.OPEN_APP, pkg))
                                    screen = Screen.Quick
                                },
                                back = Screen.Quick
                            )
                        },
                        onBack = { screen = Screen.Home }
                    )

                    is Screen.ShortcutEdit -> ShortcutEditScreen(
                        state = state,
                        id = s.id,
                        onPickAction = { sc ->
                            val req = PickReq(
                                title = sc.displayName(this),
                                current = sc.action,
                                allowPass = false,
                                allowNone = false,
                                noneLabel = R.string.a_none,
                                noneDesc = R.string.a_none_desc,
                                onResult = { ref -> state.updateShortcut(sc.id) { it.copy(action = ref) } }
                            )
                            screen = Screen.Picker(req, s)
                        },
                        onBack = { screen = Screen.Quick }
                    )

                    Screen.Profiles -> ProfilesScreen(
                        state = state,
                        onBack = { screen = Screen.Home }
                    )

                    is Screen.Picker -> ActionPickerScreen(
                        req = s.req,
                        onChooseApp = {
                            screen = Screen.AppChoose(
                                onPick = { pkg ->
                                    s.req.onResult(ActionRef(ActionType.OPEN_APP, pkg))
                                    screen = s.back
                                },
                                back = s
                            )
                        },
                        onDone = { ref ->
                            s.req.onResult(ref)
                            screen = s.back
                        },
                        onBack = { screen = s.back }
                    )

                    is Screen.AppChoose -> AppChooseScreen(
                        onPick = { pkg -> s.onPick(pkg) },
                        onBack = { screen = s.back }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        state.refresh()
        resumeTick.intValue++
    }

    private fun isAccessibilityEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val mine = ComponentName(context, VolumeScrollService::class.java)
        return enabled.split(':').any { ComponentName.unflattenFromString(it) == mine }
    }
}
