package com.volumescroll.app

import android.app.Application

class VolumeScrollApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
    }
}
