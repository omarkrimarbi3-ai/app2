package com.volumescroll.app

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile: instant on/off of everything (the quick "pause"). */
class ToggleTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        update()
    }

    override fun onClick() {
        super.onClick()
        Prefs.init(this)
        Prefs.enabled = !Prefs.enabled
        update()
    }

    private fun update() {
        Prefs.init(this)
        val tile = qsTile ?: return
        val on = Prefs.enabled
        val text = Lang.wrap(this)
        tile.state = if (on) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = text.getString(R.string.app_name)
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            tile.subtitle = text.getString(if (on) R.string.tile_on else R.string.tile_off)
        }
        tile.updateTile()
    }
}
