package com.volumescroll.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast

/** Runs actions. Never throws: a failing action must not take the accessibility service down. */
object ActionExecutor {

    private val CALCULATOR_PACKAGES = listOf(
        "com.google.android.calculator",
        "com.android.calculator2",
        "com.miui.calculator",
        "com.sec.android.app.popupcalculator",
        "com.oneplus.calculator",
        "com.coloros.calculator",
        "com.oppo.calculator",
        "com.huawei.calculator",
        "com.vivo.calculator",
        "com.asus.calculator",
        "com.motorola.calculator"
    )

    fun execute(service: VolumeScrollService, ref: ActionRef, keyCode: Int) {
        try {
            perform(service, ref, keyCode)
        } catch (e: Exception) {
            // Ignore: the action is unavailable or blocked on this device.
        }
    }

    private fun perform(service: VolumeScrollService, ref: ActionRef, keyCode: Int) {
        when (ref.type) {
            ActionType.NONE -> Unit
            ActionType.PASS_THROUGH -> adjust(
                service,
                if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE
                else AudioManager.ADJUST_LOWER
            )
            ActionType.SCROLL_UP -> service.scroll(false)
            ActionType.SCROLL_DOWN -> service.scroll(true)
            ActionType.VOLUME_UP -> adjust(service, AudioManager.ADJUST_RAISE)
            ActionType.VOLUME_DOWN -> adjust(service, AudioManager.ADJUST_LOWER)
            ActionType.VOLUME_PANEL -> adjust(service, AudioManager.ADJUST_SAME)
            ActionType.MEDIA_PLAY_PAUSE -> media(service, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            ActionType.MEDIA_NEXT -> media(service, KeyEvent.KEYCODE_MEDIA_NEXT)
            ActionType.MEDIA_PREVIOUS -> media(service, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            ActionType.FLASHLIGHT -> Torch.toggle(service)
            ActionType.CAMERA -> openCamera(service)
            ActionType.CALCULATOR -> findCalculator(service)?.let { launch(service, it) }
            ActionType.HOME -> service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
            ActionType.BACK -> service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            ActionType.RECENTS -> service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
            ActionType.NOTIFICATIONS -> service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
            ActionType.QUICK_SETTINGS -> service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
            ActionType.SETTINGS -> launch(service, Intent(Settings.ACTION_SETTINGS))
            ActionType.DISPLAY_SETTINGS -> launch(service, Intent(Settings.ACTION_DISPLAY_SETTINGS))
            ActionType.NEXT_PROFILE -> nextProfile(service)
            ActionType.OPEN_APP -> ref.arg?.let { pkg ->
                service.packageManager.getLaunchIntentForPackage(pkg)?.let { launch(service, it) }
            }
        }
    }

    /** Same call the system makes for the hardware keys; FLAG_SHOW_UI shows the volume panel. */
    private fun adjust(service: VolumeScrollService, direction: Int) {
        val am = service.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustSuggestedStreamVolume(
            direction,
            AudioManager.USE_DEFAULT_STREAM_TYPE,
            AudioManager.FLAG_SHOW_UI
        )
    }

    private fun media(service: VolumeScrollService, keyCode: Int) {
        val am = service.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }

    private fun nextProfile(service: VolumeScrollService) {
        val list = Prefs.profiles()
        val index = list.indexOfFirst { it.id == Prefs.activeId }
        val next = list[(index + 1).mod(list.size)]
        Prefs.activeId = next.id
        val text = next.emoji + " " + next.displayName(Lang.wrap(service))
        Toast.makeText(service, text, Toast.LENGTH_SHORT).show()
    }

    /** Opens the phone's own camera app directly, so no "Complete action using" chooser appears. */
    private fun openCamera(service: VolumeScrollService) {
        val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        val systemMask = ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP
        val system = service.packageManager.queryIntentActivities(intent, 0).firstOrNull {
            (it.activityInfo.applicationInfo.flags and systemMask) != 0
        }
        if (system != null) {
            intent.setClassName(system.activityInfo.packageName, system.activityInfo.name)
        }
        launch(service, intent)
    }

    private fun launch(service: VolumeScrollService, intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        service.startActivity(intent)
    }

    /** Only actions that can really run on this phone are offered in the UI. */
    fun isAvailable(context: Context, type: ActionType): Boolean {
        val pm = context.packageManager
        return when (type) {
            ActionType.FLASHLIGHT -> pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)
            ActionType.CAMERA -> pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
            ActionType.CALCULATOR -> findCalculator(context) != null
            else -> true
        }
    }

    private fun findCalculator(context: Context): Intent? {
        val pm = context.packageManager
        for (pkg in CALCULATOR_PACKAGES) {
            val intent = pm.getLaunchIntentForPackage(pkg)
            if (intent != null) return intent
        }
        return null
    }

    fun label(context: Context, ref: ActionRef, singlePress: Boolean): String = when (ref.type) {
        ActionType.NONE ->
            context.getString(if (singlePress) R.string.a_none_single else R.string.a_none)
        ActionType.OPEN_APP -> {
            val name = appName(context, ref.arg)
            if (name != null) context.getString(R.string.a_open_app_named, name)
            else context.getString(R.string.a_open_app)
        }
        else -> context.getString(ref.type.label)
    }

    internal fun appName(context: Context, pkg: String?): String? {
        if (pkg == null) return null
        return try {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            null
        }
    }
}

/** Flashlight without any permission: CameraManager.setTorchMode. */
object Torch {
    @Volatile private var on = false
    private var cameraId: String? = null
    private var registered = false

    fun init(context: Context) {
        if (registered) return
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val withFlash = cm.cameraIdList.filter {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            cameraId = withFlash.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) ==
                    CameraCharacteristics.LENS_FACING_BACK
            } ?: withFlash.firstOrNull()
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(id: String, enabled: Boolean) {
                    if (id == cameraId) on = enabled
                }
            }, null)
            registered = true
        } catch (e: Exception) {
            // No flashlight on this device.
        }
    }

    fun toggle(context: Context) {
        init(context)
        val id = cameraId ?: return
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cm.setTorchMode(id, !on)
    }
}
