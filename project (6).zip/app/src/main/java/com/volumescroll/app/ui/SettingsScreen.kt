package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.volumescroll.app.Lang
import com.volumescroll.app.Prefs
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    state: SettingsState,
    serviceOn: Boolean,
    onOpenAccessibility: () -> Unit,
    onOpenAppInfo: () -> Unit,
    onLanguageChanged: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(stringResource(R.string.settings_title), null, onBack)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Language
            SectionCard {
                SectionTitle(stringResource(R.string.lang_title))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LanguageChip(R.string.lang_ar, Lang.AR, state, onLanguageChanged, Modifier.weight(1f))
                    LanguageChip(R.string.lang_en, Lang.EN, state, onLanguageChanged, Modifier.weight(1f))
                    LanguageChip(R.string.lang_system, Lang.SYSTEM, state, onLanguageChanged, Modifier.weight(1f))
                }
            }

            // Scroll speed
            SectionCard {
                SectionTitle(stringResource(R.string.speed_title))
                HintText(stringResource(R.string.speed_desc))
                Slider(
                    value = state.speed.toFloat(),
                    onValueChange = { state.changeSpeed(it.roundToInt()) },
                    valueRange = Prefs.MIN_SPEED.toFloat()..Prefs.MAX_SPEED.toFloat(),
                    steps = Prefs.MAX_SPEED - Prefs.MIN_SPEED - 1
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(stringResource(R.string.speed_slow), style = MaterialTheme.typography.labelMedium)
                    Text(
                        "${state.speed}/${Prefs.MAX_SPEED}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(stringResource(R.string.speed_fast), style = MaterialTheme.typography.labelMedium)
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            stringResource(R.string.reverse_title),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            stringResource(R.string.reverse_desc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = state.reverse, onCheckedChange = { state.changeReverse(it) })
                }
            }

            // Permissions
            SectionCard {
                SectionTitle(stringResource(R.string.perm_title))
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        stringResource(R.string.perm_a11y_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        stringResource(if (serviceOn) R.string.perm_on else R.string.perm_off),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = if (serviceOn) Accent.Green else MaterialTheme.colorScheme.error
                    )
                }
                HintText(stringResource(R.string.perm_a11y_why))
                Button(
                    onClick = onOpenAccessibility,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(stringResource(R.string.perm_open), fontWeight = FontWeight.SemiBold) }

                if (!serviceOn) {
                    Text(
                        stringResource(R.string.perm_restricted_title),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    HintText(stringResource(R.string.perm_restricted_body))
                    OutlinedButton(
                        onClick = onOpenAppInfo,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().height(52.dp)
                    ) { Text(stringResource(R.string.perm_restricted_open)) }
                }
                Text(
                    stringResource(R.string.perm_none),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // How to use
            SectionCard {
                SectionTitle(stringResource(R.string.howto_title))
                listOf(R.string.howto_1, R.string.howto_2, R.string.howto_3, R.string.howto_4).forEach {
                    Text(stringResource(it), style = MaterialTheme.typography.bodyMedium)
                }
            }

            // Limits
            SectionCard {
                SectionTitle(stringResource(R.string.limits_title))
                Text(stringResource(R.string.limits_body), style = MaterialTheme.typography.bodyMedium)
            }

            Text(
                stringResource(R.string.about_version),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun LanguageChip(
    labelRes: Int,
    code: String,
    state: SettingsState,
    onChanged: () -> Unit,
    modifier: Modifier
) {
    PillChip(
        label = stringResource(labelRes),
        selected = state.language == code,
        modifier = modifier
    ) {
        if (state.language != code) {
            state.changeLanguage(code)
            onChanged()
        }
    }
}
