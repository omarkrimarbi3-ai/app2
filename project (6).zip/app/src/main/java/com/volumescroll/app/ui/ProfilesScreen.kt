package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.volumescroll.app.Prefs
import com.volumescroll.app.Profile
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState

private val PROFILE_EMOJIS = listOf(
    "⚪", "🌐", "🎮", "🎵", "📚", "🚗",
    "💼", "🏠", "🌙", "🏃", "📷", "⚡"
)

@Composable
fun ProfilesScreen(state: SettingsState, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    var creating by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Profile?>(null) }
    var deleting by remember { mutableStateOf<Profile?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(stringResource(R.string.pf_title), null, onBack)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            HintText(stringResource(R.string.pf_desc))

            state.profiles.forEach { p ->
                ProfileRow(
                    profile = p,
                    active = p.id == state.activeId,
                    onActivate = { state.switchProfile(p.id) },
                    onEdit = { editing = p },
                    onDelete = { deleting = p }
                )
            }

            Button(
                onClick = { creating = true },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(stringResource(R.string.pf_add), fontWeight = FontWeight.SemiBold) }
        }
    }

    if (creating) {
        ProfileDialog(
            initial = null,
            onDismiss = { creating = false },
            onSave = { name, emoji ->
                state.addProfile(name, emoji)
                creating = false
            }
        )
    }

    val toEdit = editing
    if (toEdit != null) {
        ProfileDialog(
            initial = toEdit,
            onDismiss = { editing = null },
            onSave = { name, emoji ->
                state.editProfile(toEdit.id, name, emoji)
                editing = null
            }
        )
    }

    val toDelete = deleting
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            confirmButton = {
                TextButton(onClick = {
                    state.removeProfile(toDelete.id)
                    deleting = null
                }) { Text(stringResource(R.string.delete)) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text(stringResource(R.string.cancel)) }
            },
            title = { Text(stringResource(R.string.pf_delete_title)) },
            text = { Text(stringResource(R.string.pf_delete_body, toDelete.displayName(context))) }
        )
    }
}

@Composable
private fun ProfileRow(
    profile: Profile,
    active: Boolean,
    onActivate: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onActivate,
        shape = RoundedCornerShape(22.dp),
        color = if (active) cs.primaryContainer else cs.surfaceVariant,
        border = BorderStroke(if (active) 2.dp else 1.dp, if (active) cs.primary else cs.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(profile.emoji, fontSize = 28.sp)
            Column(Modifier.weight(1f)) {
                Text(
                    profile.displayName(context),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (active) {
                    Text(
                        stringResource(R.string.pf_active),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
            TextButton(onClick = onEdit) { Text(stringResource(R.string.edit)) }
            if (profile.id != Prefs.DEFAULT_PROFILE) {
                TextButton(onClick = onDelete) {
                    Text(stringResource(R.string.delete), color = cs.error)
                }
            }
        }
    }
}

@Composable
private fun ProfileDialog(
    initial: Profile?,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var emoji by remember { mutableStateOf(initial?.emoji ?: "⚪") }
    val isDefault = initial?.id == Prefs.DEFAULT_PROFILE

    val templates = listOf(
        Pair(stringResource(R.string.pf_t_browsing), "🌐"),
        Pair(stringResource(R.string.pf_t_gaming), "🎮"),
        Pair(stringResource(R.string.pf_t_music), "🎵"),
        Pair(stringResource(R.string.pf_t_normal), "⚪")
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(
                onClick = { onSave(name.trim(), emoji) },
                enabled = name.isNotBlank() || isDefault
            ) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        },
        title = {
            Text(stringResource(if (initial == null) R.string.pf_add else R.string.pf_edit))
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    label = { Text(stringResource(R.string.pf_name)) },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    templates.forEach { t ->
                        PillChip(label = t.second + " " + t.first, selected = false) {
                            name = t.first
                            emoji = t.second
                        }
                    }
                }
                EmojiGrid(PROFILE_EMOJIS, emoji) { e -> emoji = e }
            }
        }
    )
}
