package com.volumescroll.app

import android.content.Context

/** A named set of settings (buttons, rules, floating shortcut). "default" is the built-in one. */
data class Profile(val id: String, val name: String, val emoji: String) {
    fun displayName(context: Context): String =
        if (name.isNotBlank()) name else context.getString(R.string.profile_normal)
}

/** A user shortcut: an action with a name and an icon. Shown in the floating shortcut menu. */
data class Shortcut(
    val id: String,
    val name: String,
    val emoji: String?,
    val action: ActionRef
) {
    fun displayName(context: Context): String {
        if (name.isNotBlank()) return name
        if (action.type == ActionType.OPEN_APP) {
            val app = ActionExecutor.appName(context, action.arg)
            if (app != null) return app
        }
        return ActionExecutor.label(context, action, false)
    }
}

enum class BubbleShape { CIRCLE, ROUNDED, CAPSULE }

enum class BubbleTrigger { TAP, LONG, DOUBLE }

object BubbleStyle {
    val COLORS: IntArray = intArrayOf(
        0xFF6D4AFF.toInt(),
        0xFFE6397A.toInt(),
        0xFFF0701E.toInt(),
        0xFF0F9D8A.toInt(),
        0xFF2F6FE4.toInt(),
        0xFF2E9E5B.toInt(),
        0xFF1B1B25.toInt()
    )

    val EMOJIS: List<String> = listOf(
        "⚡", "🎛️", "🔥", "⭐", "🚀", "🎯",
        "💡", "🎵", "🎮", "🌐", "📷", "🔦",
        "🏠", "📱", "⚙️", "🔔", "🧭", "🧩",
        "🎨", "💬", "📌", "🛠️", "🔒", "❤️"
    )

    const val MIN_SIZE = 40
    const val MAX_SIZE = 80
    const val MIN_ALPHA = 30
}

data class BubbleCfg(
    val enabled: Boolean = false,
    val shape: BubbleShape = BubbleShape.CIRCLE,
    val emoji: String = "⚡",
    val sizeDp: Int = 56,
    val alphaPct: Int = 90,
    val colorIdx: Int = 0,
    val right: Boolean = true,
    val yPct: Int = 40,
    val trigger: BubbleTrigger = BubbleTrigger.TAP
)
