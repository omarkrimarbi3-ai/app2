package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState

@Composable
fun AppsScreen(state: SettingsState, onBack: () -> Unit) {
    BackHandler(onBack = onBack)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(
            title = stringResource(R.string.apps_choose),
            subtitle = "${state.apps.size} " + stringResource(R.string.stat_apps),
            onBack = onBack
        )
        AppPickerList(
            trailing = { app ->
                Switch(
                    checked = app.pkg in state.apps,
                    onCheckedChange = { state.toggleApp(app.pkg) }
                )
            },
            onItemClick = { app -> state.toggleApp(app.pkg) }
        )
    }
}
