package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.volumescroll.app.ActionExecutor
import com.volumescroll.app.Btn
import com.volumescroll.app.Gest
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState
import com.volumescroll.app.Source

@Composable
fun AppRulesScreen(
    state: SettingsState,
    onAdd: () -> Unit,
    onOpen: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(
            stringResource(R.string.rules_title),
            state.activeProfile.emoji + " " + state.activeProfile.displayName(LocalContext.current),
            onBack
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            HintText(stringResource(R.string.rules_desc))

            if (state.rules.isEmpty()) {
                SectionCard {
                    Text(
                        stringResource(R.string.rules_empty),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            state.rules.sorted().forEach { pkg ->
                RuleRow(state, pkg) { onOpen(pkg) }
            }

            Button(
                onClick = onAdd,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(stringResource(R.string.rules_add), fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
private fun RuleRow(state: SettingsState, pkg: String, onClick: () -> Unit) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val name = ActionExecutor.appName(context, pkg) ?: pkg
    val icon = appIconBitmap(pkg)
    val source = Source.App(pkg)

    val up = ActionExecutor.label(context, state.action(source, Btn.UP, Gest.SINGLE), true)
    val down = ActionExecutor.label(context, state.action(source, Btn.DOWN, Gest.SINGLE), true)
    val summary = stringResource(R.string.bc_vol_up) + ": " + up + "  ·  " +
        stringResource(R.string.bc_vol_down) + ": " + down

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        color = cs.surfaceVariant,
        border = BorderStroke(1.dp, cs.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (icon != null) {
                Image(bitmap = icon, contentDescription = null, modifier = Modifier.size(46.dp))
            } else {
                Box(Modifier.size(46.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    summary,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
