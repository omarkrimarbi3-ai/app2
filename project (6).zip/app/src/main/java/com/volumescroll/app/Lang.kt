package com.volumescroll.app

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** In-app language (Arabic / English / follow the system). */
object Lang {
    const val SYSTEM = "system"
    const val AR = "ar"
    const val EN = "en"

    fun wrap(base: Context): Context {
        if (!Prefs.isReady) return base
        val code = Prefs.language
        if (code == SYSTEM) return base
        val locale = Locale(code)
        val conf = Configuration(base.resources.configuration)
        conf.setLocale(locale)
        conf.setLayoutDirection(locale)
        return base.createConfigurationContext(conf)
    }
}
