package com.volumescroll.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.volumescroll.app.ActionExecutor
import com.volumescroll.app.ActionRef
import com.volumescroll.app.ActionType
import com.volumescroll.app.BubbleStyle
import com.volumescroll.app.Category
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState
import com.volumescroll.app.Shortcut

@Composable
fun QuickActionsScreen(
    state: SettingsState,
    onEdit: (String) -> Unit,
    onAddCustom: () -> Unit,
    onAddApp: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(stringResource(R.string.qa_title), stringResource(R.string.qa_subtitle), onBack)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard {
                SectionTitle(stringResource(R.string.qa_my_shortcuts))
                if (state.shortcuts.isEmpty()) {
                    HintText(stringResource(R.string.qa_empty))
                }
                state.shortcuts.forEachIndexed { index, sc ->
                    ShortcutRow(
                        sc = sc,
                        inBubble = sc.id in state.bubbleIds,
                        canUp = index > 0,
                        canDown = index < state.shortcuts.size - 1,
                        onClick = { onEdit(sc.id) },
                        onToggle = { state.toggleInBubble(sc.id) },
                        onUp = { state.moveShortcut(sc.id, -1) },
                        onDown = { state.moveShortcut(sc.id, 1) }
                    )
                }
                Button(
                    onClick = onAddCustom,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) { Text(stringResource(R.string.qa_add_custom), fontWeight = FontWeight.SemiBold) }
            }

            HintText(stringResource(R.string.qa_library_hint))

            Category.values().forEach { category ->
                val types = ActionType.values().filter {
                    it.category == category && ActionExecutor.isAvailable(context, it)
                }
                if (types.isNotEmpty()) {
                    SectionCard {
                        SectionTitle(stringResource(category.label))
                        types.forEach { type ->
                            LibraryRow(
                                emoji = type.emoji,
                                label = stringResource(type.label)
                            ) {
                                if (type == ActionType.OPEN_APP) {
                                    onAddApp()
                                } else {
                                    state.addShortcut(ActionRef(type))
                                    toast(context, R.string.qa_added)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryRow(emoji: String, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(emoji, fontSize = 22.sp, modifier = Modifier.padding(end = 14.dp))
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Text(
            "＋",
            color = MaterialTheme.colorScheme.primary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun ShortcutIcon(sc: Shortcut, size: Int) {
    val cs = MaterialTheme.colorScheme
    val pkg = sc.action.arg
    val bitmap = if (sc.emoji == null && sc.action.type == ActionType.OPEN_APP && pkg != null) {
        appIconBitmap(pkg)
    } else {
        null
    }
    Box(
        modifier = Modifier
            .size(size.dp)
            .clip(RoundedCornerShape(14.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(bitmap = bitmap, contentDescription = null, modifier = Modifier.size(size.dp))
        } else {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = cs.primaryContainer,
                modifier = Modifier.size(size.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(sc.emoji ?: sc.action.type.emoji, fontSize = (size * 0.5f).sp)
                }
            }
        }
    }
}

@Composable
private fun ShortcutRow(
    sc: Shortcut,
    inBubble: Boolean,
    canUp: Boolean,
    canDown: Boolean,
    onClick: () -> Unit,
    onToggle: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit
) {
    val context = LocalContext.current
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = cs.background,
        border = androidx.compose.foundation.BorderStroke(1.dp, cs.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ShortcutIcon(sc, 44)
            Column(Modifier.weight(1f)) {
                Text(
                    sc.displayName(context),
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    stringResource(if (inBubble) R.string.qa_in_bubble else R.string.qa_not_in_bubble),
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant
                )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                TinyAction("▲", canUp, onUp)
                TinyAction("▼", canDown, onDown)
            }
            Switch(checked = inBubble, onCheckedChange = { onToggle() })
        }
    }
}

@Composable
fun ShortcutEditScreen(
    state: SettingsState,
    id: String,
    onPickAction: (Shortcut) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val sc = state.shortcuts.firstOrNull { it.id == id }
    if (sc == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }
    var name by remember(id) { mutableStateOf(sc.name) }
    val cs = MaterialTheme.colorScheme

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        ScreenTopBar(stringResource(R.string.se_title), sc.displayName(context), onBack)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            SectionCard {
                SectionTitle(stringResource(R.string.se_name))
                OutlinedTextField(
                    value = name,
                    onValueChange = { v ->
                        name = v
                        state.updateShortcut(id) { it.copy(name = v) }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    placeholder = { Text(sc.copy(name = "").displayName(context)) },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            SectionCard {
                SectionTitle(stringResource(R.string.se_action))
                Surface(
                    onClick = { onPickAction(sc) },
                    shape = RoundedCornerShape(16.dp),
                    color = cs.primaryContainer,
                    contentColor = cs.onPrimaryContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(sc.action.type.emoji, fontSize = 22.sp)
                        Text(
                            ActionExecutor.label(context, sc.action, false),
                            modifier = Modifier.weight(1f),
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(stringResource(R.string.se_change), color = cs.primary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            SectionCard {
                SectionTitle(stringResource(R.string.se_icon))
                OutlinedButton(
                    onClick = { state.updateShortcut(id) { it.copy(emoji = null) } },
                    shape = RoundedCornerShape(16.dp),
                    enabled = sc.emoji != null,
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) { Text(stringResource(R.string.se_icon_auto)) }
                EmojiGrid(BubbleStyle.EMOJIS, sc.emoji) { e -> state.updateShortcut(id) { it.copy(emoji = e) } }
            }

            SectionCard {
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        SectionTitle(stringResource(R.string.se_in_bubble))
                        HintText(stringResource(R.string.se_in_bubble_desc))
                    }
                    Switch(
                        checked = sc.id in state.bubbleIds,
                        onCheckedChange = { state.toggleInBubble(sc.id) }
                    )
                }
            }

            OutlinedButton(
                onClick = {
                    state.removeShortcut(id)
                    onBack()
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(stringResource(R.string.se_delete)) }
        }
    }
}
