package com.volumescroll.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.material3.Surface
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.volumescroll.app.R
import com.volumescroll.app.SettingsState

enum class Dest { BUTTONS, BUBBLE, QUICK, PROFILES, RULES, SETTINGS }

@Composable
fun HomeScreen(
    state: SettingsState,
    serviceOn: Boolean,
    onOpenAccessibility: () -> Unit,
    onNavigate: (Dest) -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Header { onNavigate(Dest.SETTINGS) }

        // Profiles: one tap to switch (only shown when there is more than one).
        if (state.profiles.size > 1) Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            state.profiles.forEach { p ->
                PillChip(
                    label = p.emoji + " " + p.displayName(context),
                    selected = p.id == state.activeId
                ) { state.switchProfile(p.id) }
            }
        }

        PowerCard(
            serviceOn = serviceOn,
            enabled = state.enabled,
            onClick = {
                if (!serviceOn) onOpenAccessibility() else state.changeEnabled(!state.enabled)
            }
        )

        if (!serviceOn) {
            OutlinedButton(
                onClick = { onNavigate(Dest.SETTINGS) },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) { Text(stringResource(R.string.home_help_enable)) }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HubCard(HubIcons.Buttons, stringResource(R.string.hub_buttons), Color.White, Modifier.weight(1f)) { onNavigate(Dest.BUTTONS) }
            HubCard(HubIcons.Bubble, stringResource(R.string.hub_bubble), Color.White, Modifier.weight(1f)) { onNavigate(Dest.BUBBLE) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HubCard(HubIcons.Quick, stringResource(R.string.hub_quick), Color.White, Modifier.weight(1f)) { onNavigate(Dest.QUICK) }
            HubCard(HubIcons.Rules, stringResource(R.string.hub_rules), Color.White, Modifier.weight(1f)) { onNavigate(Dest.RULES) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HubCard(HubIcons.Profiles, stringResource(R.string.hub_profiles), Color.White, Modifier.weight(1f)) { onNavigate(Dest.PROFILES) }
            HubCard(HubIcons.Settings, stringResource(R.string.hub_settings), Color.White, Modifier.weight(1f)) { onNavigate(Dest.SETTINGS) }
        }
    }
}

@Composable
private fun Header(onSettings: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Image(
            painter = painterResource(R.drawable.ic_logo),
            contentDescription = null,
            modifier = Modifier.size(52.dp)
        )
        Column(Modifier.weight(1f)) {
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF16161F)
            )
            Text(
                stringResource(R.string.tagline),
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF5B5B6B)
            )
        }
        Surface(
            onClick = onSettings,
            shape = CircleShape,
            color = Color.White,
            shadowElevation = 4.dp,
            border = BorderStroke(1.dp, Color(0xFFE3E3EC)),
            modifier = Modifier.size(46.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    HubIcons.Settings,
                    contentDescription = stringResource(R.string.hub_settings),
                    tint = Color(0xFF16161F),
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
private fun PowerCard(serviceOn: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val active = serviceOn && enabled
    val c = MaterialTheme.colorScheme.primary
    val colors = listOf(c, c)
    val title = when {
        !serviceOn -> R.string.status_setup
        !enabled -> R.string.status_off
        else -> R.string.status_active
    }
    val hint = when {
        !serviceOn -> R.string.status_setup_hint
        !enabled -> R.string.status_off_hint
        else -> R.string.status_active_hint
    }

    GradientCard(colors = colors, modifier = Modifier.fillMaxWidth(), onClick = onClick) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    when {
                        !serviceOn -> HubIcons.Warn
                        active -> HubIcons.Active
                        else -> HubIcons.Paused
                    },
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(44.dp)
                )
            }
            Text(
                stringResource(title),
                color = MaterialTheme.colorScheme.onPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                stringResource(hint),
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun ArrowsGlyph(color: Color) {
    Canvas(Modifier.size(56.dp)) {
        val w = size.width
        val h = size.height
        val up = Path().apply {
            moveTo(w * 0.5f, h * 0.04f)
            lineTo(w * 0.86f, h * 0.46f)
            lineTo(w * 0.14f, h * 0.46f)
            close()
        }
        val down = Path().apply {
            moveTo(w * 0.5f, h * 0.96f)
            lineTo(w * 0.14f, h * 0.54f)
            lineTo(w * 0.86f, h * 0.54f)
            close()
        }
        drawPath(up, color)
        drawPath(down, color)
    }
}

@Composable
private fun HubCard(
    icon: ImageVector,
    title: String,
    @Suppress("UNUSED_PARAMETER") color: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(26.dp),
        color = cs.surfaceVariant,
        shadowElevation = 6.dp,
        border = BorderStroke(1.dp, cs.outline),
        modifier = modifier.height(128.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            IconBadge(icon, size = 62)
            Text(
                title,
                color = cs.onSurface,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}
