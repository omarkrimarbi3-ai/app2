package com.volumescroll.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.volumescroll.app.ui.IconSet
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.min

/**
 * The floating shortcut. It is drawn by the accessibility service as an accessibility overlay,
 * so it needs no "display over other apps" permission and no notification.
 */
class BubbleController(private val service: VolumeScrollService) {

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val slop = ViewConfiguration.get(service).scaledTouchSlop

    private var bubble: ImageView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var menu: View? = null
    private var detector: GestureDetector? = null

    private fun dp(v: Float): Float = v * service.resources.displayMetrics.density
    private fun dpi(v: Int): Int = dp(v.toFloat()).toInt()

    /** Shows, updates or hides the bubble according to the current settings. */
    fun sync() {
        val cfg = Prefs.bubble()
        if (!Prefs.enabled || !cfg.enabled) {
            remove()
            return
        }
        try {
            show(cfg)
        } catch (e: Exception) {
            // The system refused the overlay: keep the rest of the service working.
        }
    }

    fun remove() {
        closeMenu()
        val view = bubble
        if (view != null) {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
                // Already removed.
            }
        }
        bubble = null
        bubbleParams = null
    }

    private fun show(cfg: BubbleCfg) {
        val dm = service.resources.displayMetrics
        val size = dpi(cfg.sizeDp)
        val w = if (cfg.shape == BubbleShape.CAPSULE) (size * 1.6f).toInt() else size
        val h = size

        val view = bubble ?: createBubbleView().also { bubble = it }
        val params = bubbleParams ?: WindowManager.LayoutParams(
            w,
            h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).also {
            it.gravity = Gravity.TOP or Gravity.START
            bubbleParams = it
        }
        params.width = w
        params.height = h
        params.x = if (cfg.right) dm.widthPixels - w else 0
        params.y = ((dm.heightPixels - h) * cfg.yPct / 100f).toInt()

        val bg = GradientDrawable()
        bg.setColor(BubbleStyle.COLORS[cfg.colorIdx.coerceIn(0, BubbleStyle.COLORS.size - 1)])
        bg.cornerRadius = when (cfg.shape) {
            BubbleShape.CIRCLE -> h / 2f
            BubbleShape.ROUNDED -> h * 0.3f
            BubbleShape.CAPSULE -> h / 2f
        }
        bg.setStroke(dpi(2), 0x55FFFFFF)
        view.background = bg
        val pad = (size * 0.24f).toInt()
        view.setPadding(pad, pad, pad, pad)
        view.setImageBitmap(IconSet.render(IconSet.forBubble(cfg.emoji), dpi(48), Color.WHITE))
        view.alpha = cfg.alphaPct / 100f
        detector = buildDetector(cfg.trigger)

        if (view.parent == null) wm.addView(view, params) else wm.updateViewLayout(view, params)
    }

    private fun createBubbleView(): ImageView {
        val view = ImageView(service)
        view.scaleType = ImageView.ScaleType.FIT_CENTER

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false

        view.setOnTouchListener { v, e ->
            detector?.onTouchEvent(e)
            val params = bubbleParams
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params?.x ?: 0
                    startY = params?.y ?: 0
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                    if (dragging && params != null) {
                        val dm = service.resources.displayMetrics
                        params.x = (startX + dx).toInt().coerceIn(0, (dm.widthPixels - params.width).coerceAtLeast(0))
                        params.y = (startY + dy).toInt().coerceIn(0, (dm.heightPixels - params.height).coerceAtLeast(0))
                        try {
                            wm.updateViewLayout(v, params)
                        } catch (ex: Exception) {
                            // View was removed while dragging.
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (dragging) {
                        dragging = false
                        snapAndSave()
                    }
                }
            }
            true
        }
        return view
    }

    /** After a drag: stick to the nearest side, remember the position. */
    private fun snapAndSave() {
        val p = bubbleParams ?: return
        val dm = service.resources.displayMetrics
        val right = p.x + p.width / 2 > dm.widthPixels / 2
        val range = (dm.heightPixels - p.height).coerceAtLeast(1)
        val yPct = (p.y * 100f / range).toInt().coerceIn(0, 100)
        Prefs.saveBubble(Prefs.bubble().copy(right = right, yPct = yPct))
        sync()
    }

    private fun buildDetector(trigger: BubbleTrigger): GestureDetector {
        val listener = object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapUp(e: MotionEvent): Boolean {
                if (trigger == BubbleTrigger.TAP) openMenu()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (trigger == BubbleTrigger.DOUBLE) openMenu()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (trigger == BubbleTrigger.LONG) openMenu()
            }
        }
        val d = GestureDetector(service, listener)
        d.setIsLongpressEnabled(trigger == BubbleTrigger.LONG)
        return d
    }

    // ---- Shortcut menu ----------------------------------------------------------------------

    private fun openMenu() {
        if (menu != null) return
        val p = bubbleParams ?: return
        try {
            val ctx = Lang.wrap(service)
            val items = Prefs.bubbleShortcuts()
            val dm = service.resources.displayMetrics

            val scrim = FrameLayout(service)
            scrim.layoutDirection = View.LAYOUT_DIRECTION_LTR
            scrim.setBackgroundColor(0x66000000)
            scrim.setOnClickListener { closeMenu() }

            // Everything is positioned from the bubble's own position, before the window is shown.
            val cx = p.x + p.width / 2f
            val cy = p.y + p.height / 2f
            layoutRadial(scrim, ctx, items, cx, cy, dm.widthPixels, dm.heightPixels, Prefs.bubble().right)

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            wm.addView(scrim, params)
            menu = scrim
            reveal(scrim)
        } catch (e: Exception) {
            menu = null
            Toast.makeText(
                service,
                "AVORA menu error: " + e.javaClass.simpleName + " " + (e.message ?: ""),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    /** Small pop-out animation; a timer makes sure every item ends fully visible. */
    private fun reveal(scrim: FrameLayout) {
        var index = 0
        for (i in 0 until scrim.childCount) {
            val v = scrim.getChildAt(i)
            if (v.tag != "item") continue
            val dx = v.getTag(R.id.tag_dx) as? Float ?: 0f
            val dy = v.getTag(R.id.tag_dy) as? Float ?: 0f
            v.translationX = dx
            v.translationY = dy
            v.scaleX = 0.3f
            v.scaleY = 0.3f
            v.alpha = 0f
            v.animate()
                .translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).alpha(1f)
                .setStartDelay(index * 18L)
                .setDuration(200L)
                .setInterpolator(android.view.animation.OvershootInterpolator(1.2f))
                .start()
            index++
        }
        handler.postDelayed({
            for (i in 0 until scrim.childCount) {
                val v = scrim.getChildAt(i)
                v.translationX = 0f
                v.translationY = 0f
                v.scaleX = 1f
                v.scaleY = 1f
                v.alpha = 1f
            }
        }, 700L)
    }

    /** Puts the shortcuts on circles around the bubble, like the quick ball of Xiaomi phones. */
    private fun layoutRadial(
        scrim: FrameLayout,
        ctx: Context,
        items: List<Shortcut>,
        cx: Float,
        cy: Float,
        width: Int,
        height: Int,
        right: Boolean
    ) {
        scrim.removeAllViews()
        val itemSize = dpi(52)
        val margin = itemSize / 2f + dp(10f)
        val marginBottom = itemSize / 2f + dp(26f)

        // Centre button: closes the menu (the bubble itself sits under the dimmed layer).
        val centerSize = dpi(Prefs.bubble().sizeDp.coerceAtMost(60))
        val close = ImageView(service)
        close.setImageBitmap(IconSet.render(IconSet.close, dpi(48), Color.WHITE))
        close.scaleType = ImageView.ScaleType.FIT_CENTER
        val cpad = (centerSize * 0.26f).toInt()
        close.setPadding(cpad, cpad, cpad, cpad)
        val closeBg = GradientDrawable()
        closeBg.setColor(BubbleStyle.COLORS[Prefs.bubble().colorIdx.coerceIn(0, BubbleStyle.COLORS.size - 1)])
        closeBg.shape = GradientDrawable.OVAL
        closeBg.setStroke(dpi(2), 0x55FFFFFF)
        close.background = closeBg
        close.elevation = dp(8f)
        close.setOnClickListener { closeMenu() }
        place(scrim, close, centerSize, cx, cy)

        if (items.isEmpty()) {
            val empty = TextView(service)
            empty.text = ctx.getString(R.string.bubble_menu_empty)
            empty.setTextColor(Color.BLACK)
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            empty.setPadding(dpi(16), dpi(12), dpi(16), dpi(12))
            empty.maxWidth = (width * 0.6f).toInt()
            val bg = GradientDrawable()
            bg.setColor(Color.WHITE)
            bg.cornerRadius = dp(18f)
            empty.background = bg
            val lp = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            )
            scrim.addView(empty, lp)
            return
        }

        // Slots on rings, facing the inside of the screen.
        val baseAngle = if (right) Math.PI else 0.0
        var remaining = items.size
        var index = 0
        var ring = 0
        while (remaining > 0 && ring < 6) {
            val radius = dp(92f) + ring * dp(76f)
            val count = (Math.PI * radius / dp(76f)).toInt() + 1
            val slots = ArrayList<FloatArray>()
            for (j in 0 until count) {
                val phi = -Math.PI / 2 + Math.PI * j / (count - 1).coerceAtLeast(1)
                val x = cx + (radius * Math.cos(baseAngle + phi)).toFloat()
                val y = cy + (radius * Math.sin(baseAngle + phi)).toFloat()
                if (x >= margin && x <= width - margin && y >= margin && y <= height - marginBottom) {
                    slots.add(floatArrayOf(x, y))
                }
            }
            val take = min(remaining, slots.size)
            for (k in 0 until take) {
                val slot = if (take == slots.size) {
                    slots[k]
                } else if (take == 1) {
                    slots[slots.size / 2]
                } else {
                    slots[Math.round(k * (slots.size - 1) / (take - 1).toFloat())]
                }
                val view = itemView(ctx, items[index], itemSize)
                placeItem(scrim, view, itemSize, slot[0], slot[1])
                view.tag = "item"
                view.setTag(R.id.tag_dx, cx - slot[0])
                view.setTag(R.id.tag_dy, cy - slot[1])
                index++
                remaining--
            }
            ring++
        }
    }

    private fun place(parent: FrameLayout, view: View, size: Int, centerX: Float, centerY: Float) {
        val lp = FrameLayout.LayoutParams(size, size)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = (centerX - size / 2f).toInt()
        lp.topMargin = (centerY - size / 2f).toInt()
        parent.addView(view, lp)
    }

    private fun placeItem(parent: FrameLayout, view: View, size: Int, centerX: Float, centerY: Float) {
        val w = dpi(76)
        val lp = FrameLayout.LayoutParams(w, size + dpi(22))
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = (centerX - w / 2f).toInt()
        lp.topMargin = (centerY - size / 2f).toInt()
        parent.addView(view, lp)
    }

    private fun itemView(ctx: Context, s: Shortcut, size: Int): View {
        val box = FrameLayout(service)
        box.clipChildren = false
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.WHITE)
        val disc = FrameLayout(service)
        disc.background = bg
        disc.elevation = dp(8f)
        box.contentDescription = s.displayName(ctx)

        var icon: View? = null
        val pkg = s.action.arg
        if (!(s.emoji ?: "").startsWith("ic:") && s.action.type == ActionType.OPEN_APP && pkg != null) {
            try {
                val image = ImageView(service)
                image.setImageDrawable(service.packageManager.getApplicationIcon(pkg))
                icon = image
            } catch (e: Exception) {
                icon = null
            }
        }
        var inner = (size * 0.62f).toInt()
        if (icon == null) {
            val image = ImageView(service)
            image.scaleType = ImageView.ScaleType.FIT_CENTER
            image.setImageBitmap(IconSet.render(IconSet.forShortcut(s), dpi(48), 0xFF16161F.toInt()))
            icon = image
            inner = (size * 0.5f).toInt()
        }
        disc.addView(icon, FrameLayout.LayoutParams(inner, inner, Gravity.CENTER))
        box.addView(disc, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        val label = TextView(service)
        label.text = s.displayName(ctx)
        label.setTextColor(Color.WHITE)
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        label.gravity = Gravity.CENTER
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        label.setShadowLayer(dp(3f), 0f, dp(1f), 0xCC000000.toInt())
        val lp = FrameLayout.LayoutParams(dpi(76), FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        lp.topMargin = size + dpi(3)
        box.addView(label, lp)

        box.setOnClickListener {
            closeMenu()
            handler.post { ActionExecutor.execute(service, s.action, 0) }
        }
        return box
    }

    private fun closeMenu() {
        val view = menu ?: return
        menu = null
        try {
            wm.removeView(view)
        } catch (e: Exception) {
            // Already removed.
        }
    }
}
