package com.volumescroll.app.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.volumescroll.app.BubbleCfg
import com.volumescroll.app.BubbleShape
import com.volumescroll.app.BubbleStyle
import com.volumescroll.app.R

@Composable
internal fun ScreenTopBar(title: String, subtitle: String?, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            if (subtitle != null) {
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
internal fun SectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = cs.surfaceVariant,
        shadowElevation = 6.dp,
        border = BorderStroke(1.dp, cs.outline),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
internal fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
}

@Composable
internal fun HintText(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
internal fun PillChip(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        color = if (selected) cs.primary else cs.surfaceVariant,
        contentColor = if (selected) cs.onPrimary else cs.onSurface,
        shadowElevation = if (selected) 2.dp else 5.dp,
        border = if (selected) null else BorderStroke(1.dp, cs.outline),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
    }
}

/** A rounded card filled with a colour gradient. Put white text inside. */
@Composable
internal fun GradientCard(
    colors: List<Color>,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val base = modifier
        .shadow(12.dp, RoundedCornerShape(28.dp))
        .clip(RoundedCornerShape(28.dp))
        .background(Brush.linearGradient(colors))
    val clickable = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(modifier = clickable.padding(20.dp), content = content)
}

@Composable
internal fun EmojiGrid(
    options: List<String>,
    selected: String?,
    columns: Int = 6,
    onSelect: (String) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.chunked(columns).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { emoji ->
                    val isSelected = emoji == selected
                    Surface(
                        onClick = { onSelect(emoji) },
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) cs.primaryContainer else cs.background,
                        border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) cs.primary else cs.outline),
                        modifier = Modifier.weight(1f).aspectRatio(1f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(emoji, fontSize = 22.sp)
                        }
                    }
                }
                repeat(columns - rowItems.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

/** The floating shortcut as it will look on screen. */
@Composable
internal fun BubblePreview(cfg: BubbleCfg, modifier: Modifier = Modifier) {
    val widthDp = if (cfg.shape == BubbleShape.CAPSULE) cfg.sizeDp * 1.6f else cfg.sizeDp.toFloat()
    val shape = when (cfg.shape) {
        BubbleShape.CIRCLE -> CircleShape
        BubbleShape.ROUNDED -> RoundedCornerShape((cfg.sizeDp * 0.3f).dp)
        BubbleShape.CAPSULE -> RoundedCornerShape((cfg.sizeDp / 2f).dp)
    }
    val color = Color(BubbleStyle.COLORS[cfg.colorIdx.coerceIn(0, BubbleStyle.COLORS.size - 1)])
    Box(
        modifier = modifier
            .size(widthDp.dp, cfg.sizeDp.dp)
            .alpha(cfg.alphaPct / 100f)
            .background(color, shape)
            .border(2.dp, Color.White.copy(alpha = 0.33f), shape),
        contentAlignment = Alignment.Center
    ) {
        Icon(IconSet.forBubble(cfg.emoji), contentDescription = null, tint = Color.White, modifier = Modifier.size((cfg.sizeDp * 0.52f).dp))
    }
}

/** The real icon of an installed app, or null if it cannot be loaded. */
@Composable
internal fun appIconBitmap(pkg: String): ImageBitmap? {
    val context = LocalContext.current
    return remember(pkg) {
        try {
            context.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
}

internal fun toast(context: Context, resId: Int) {
    Toast.makeText(context, resId, Toast.LENGTH_SHORT).show()
}

/** Small clickable text used as a lightweight button inside rows. */
@Composable
internal fun TinyAction(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    Text(
        text,
        modifier = Modifier
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
        fontSize = 14.sp
    )
}

@Composable
internal fun AvoraSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    steps: Int = 0
) {
    val cs = MaterialTheme.colorScheme
    Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = valueRange,
        steps = steps,
        colors = SliderDefaults.colors(
            thumbColor = cs.primary,
            activeTrackColor = cs.primary,
            inactiveTrackColor = cs.primaryContainer,
            activeTickColor = cs.onPrimary,
            inactiveTickColor = cs.primary.copy(alpha = 0.3f)
        )
    )
}

/** A rounded square holding one icon. */
@Composable
internal fun IconBadge(icon: ImageVector, size: Int = 44, modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier = modifier
            .size(size.dp)
            .clip(RoundedCornerShape((size * 0.32f).dp))
            .background(cs.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = cs.primary, modifier = Modifier.size((size * 0.55f).dp))
    }
}
