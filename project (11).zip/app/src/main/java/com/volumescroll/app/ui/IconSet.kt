package com.volumescroll.app.ui

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Call
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Mail
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Smartphone
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.RowScope
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.asAndroidPath
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.VectorGroup
import androidx.compose.ui.graphics.vector.VectorNode
import androidx.compose.ui.graphics.vector.VectorPath
import androidx.compose.ui.graphics.vector.toPath
import com.volumescroll.app.ActionType
import com.volumescroll.app.Shortcut

/**
 * The modern icons the user can pick for the floating button and for shortcuts.
 * The choice is stored as "ic:<name>" in the same field that used to hold an emoji.
 */
internal object IconSet {
    private const val PREFIX = "ic:"

    val all: List<Pair<String, ImageVector>> = listOf(
        "bolt" to Icons.Rounded.Bolt,
        "star" to Icons.Rounded.Star,
        "heart" to Icons.Rounded.Favorite,
        "home" to Icons.Rounded.Home,
        "bell" to Icons.Rounded.Notifications,
        "camera" to Icons.Rounded.CameraAlt,
        "torch" to Icons.Rounded.FlashlightOn,
        "music" to Icons.Rounded.MusicNote,
        "game" to Icons.Rounded.SportsEsports,
        "web" to Icons.Rounded.Language,
        "idea" to Icons.Rounded.Lightbulb,
        "tune" to Icons.Rounded.Tune,
        "gear" to Icons.Rounded.Settings,
        "apps" to Icons.Rounded.Apps,
        "compass" to Icons.Rounded.Explore,
        "puzzle" to Icons.Rounded.Extension,
        "mark" to Icons.Rounded.Bookmark,
        "search" to Icons.Rounded.Search,
        "phone" to Icons.Rounded.Smartphone,
        "call" to Icons.Rounded.Call,
        "mail" to Icons.Rounded.Mail,
        "plus" to Icons.Rounded.Add
    )

    val close: ImageVector get() = Icons.Rounded.Close

    fun key(name: String): String = PREFIX + name

    /** The icon stored in [stored] ("ic:name"), or null when it is empty or an old emoji. */
    fun fromStored(stored: String?): ImageVector? {
        if (stored == null || !stored.startsWith(PREFIX)) return null
        val name = stored.substring(PREFIX.length)
        return all.firstOrNull { it.first == name }?.second
    }

    fun forShortcut(sc: Shortcut): ImageVector = fromStored(sc.emoji) ?: sc.action.type.icon()

    fun forBubble(stored: String?): ImageVector = fromStored(stored) ?: Icons.Rounded.Bolt

    /** Draws a vector icon into a bitmap of [px] x [px] in one colour (for the overlay views). */
    fun render(icon: ImageVector, px: Int, color: Int): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = color
        paint.style = Paint.Style.FILL
        val sx = px / icon.viewportWidth
        val sy = px / icon.viewportHeight
        canvas.scale(sx, sy)
        drawNode(canvas, icon.root, paint)
        return bmp
    }

    private fun drawNode(canvas: Canvas, node: VectorNode, paint: Paint) {
        if (node is VectorGroup) {
            for (child in node) drawNode(canvas, child, paint)
        } else if (node is VectorPath) {
            val path = node.pathData.toPath().asAndroidPath()
            path.fillType = if (node.pathFillType == PathFillType.EvenOdd) {
                android.graphics.Path.FillType.EVEN_ODD
            } else {
                android.graphics.Path.FillType.WINDING
            }
            canvas.drawPath(path, paint)
        }
    }
}

/** Grid to choose one of the icons. */
@androidx.compose.runtime.Composable
internal fun IconGrid(selected: String?, columns: Int = 6, onSelect: (String) -> Unit) {
    val cs = androidx.compose.material3.MaterialTheme.colorScheme
    androidx.compose.foundation.layout.Column(
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
    ) {
        IconSet.all.chunked(columns).forEach { rowItems ->
            androidx.compose.foundation.layout.Row(
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {
                rowItems.forEach { (name, vec) ->
                    val isSel = IconSet.key(name) == selected
                    androidx.compose.material3.Surface(
                        onClick = { onSelect(IconSet.key(name)) },
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
                        color = if (isSel) cs.primaryContainer else cs.background,
                        border = androidx.compose.foundation.BorderStroke(
                            if (isSel) 2.dp else 1.dp,
                            if (isSel) cs.primary else cs.outline
                        ),
                        modifier = androidx.compose.ui.Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                    ) {
                        androidx.compose.foundation.layout.Box(contentAlignment = androidx.compose.ui.Alignment.Center) {
                            androidx.compose.material3.Icon(
                                vec, contentDescription = null, tint = cs.primary,
                                modifier = androidx.compose.ui.Modifier.size(24.dp)
                            )
                        }
                    }
                }
                repeat(columns - rowItems.size) {
                    androidx.compose.foundation.layout.Spacer(androidx.compose.ui.Modifier.weight(1f))
                }
            }
        }
    }
}
